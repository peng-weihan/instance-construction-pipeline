mod expand_repeats;
mod expand_tokens;
mod extract_default_aliases;
mod extract_tokens;
mod flatten_grammar;
mod intern_symbols;
mod pattern;
mod process_inlines;

use std::{
    cmp::Ordering,
    collections::{BTreeSet, hash_map},
    mem,
};

pub use expand_repeats::ExpandRepeatsError;
#[cfg(test)]
pub use expand_tokens::expand_tokens;
pub use expand_tokens::{
    ExpandRegexError, ExpandRuleError, ExpandTokensError, ExpandTokensProcessingError,
    NonAsciiByteClassError,
};
pub use extract_tokens::{ExtractTokensError, NonTerminalWordTokenError};
pub use flatten_grammar::FlattenGrammarError;
use indexmap::IndexMap;
pub use intern_symbols::InternSymbolsError;
pub use pattern::{PatternSpan, RegexError, RegexErrorKind};
pub use process_inlines::ProcessInlinesError;
use rustc_hash::{FxHashMap, FxHashSet};
use serde::{Deserialize, Serialize};
use thiserror::Error;

use crate::{
    bitvec::BitVec,
    grammars::{InputGrammar, PrecedenceEntry, ProductionStore, VariableType},
    nfa::NfaState,
    rules::{Symbol, SymbolView},
    strpool::StrPool,
};

use self::{
    expand_repeats::expand_repeats, extract_default_aliases::extract_default_aliases,
    extract_tokens::extract_tokens, flatten_grammar::flatten_grammar,
    intern_symbols::intern_symbols, process_inlines::process_inlines,
};
use super::{
    Diagnostic,
    grammars::{InlinedProductionMap, LexicalGrammar, SyntaxGrammar},
    prepare_grammar::flatten_grammar::{FlattenState, assemble_syntax_grammar},
    rules::{AliasMap, Precedence, Rule, RuleId},
    strpool::StrId,
};

pub type PrepareGrammarResult<T> = Result<T, PrepareGrammarError>;

#[derive(Debug, Error, Serialize, Deserialize, PartialEq, Eq)]
#[error(transparent)]
pub enum PrepareGrammarError {
    ValidatePrecedences(#[from] ValidatePrecedenceError),
    ValidateIndirectRecursion(#[from] IndirectRecursionError),
    ExpandRepeats(#[from] ExpandRepeatsError),
    InternSymbols(#[from] InternSymbolsError),
    ExtractTokens(#[from] ExtractTokensError),
    FlattenGrammar(#[from] FlattenGrammarError),
    ExpandTokens(#[from] ExpandTokensError),
    ProcessInlines(#[from] ProcessInlinesError),
    ValidateExtras(#[from] EmptyStringExtraError),
}

pub type ValidatePrecedenceResult<T> = Result<T, ValidatePrecedenceError>;

#[derive(Debug, Error, Serialize, Deserialize, PartialEq, Eq)]
#[error(transparent)]
pub enum ValidatePrecedenceError {
    Undeclared(#[from] UndeclaredPrecedenceError),
    Ordering(#[from] ConflictingPrecedenceOrderingError),
}

#[derive(Debug, Error, Serialize, Deserialize, PartialEq, Eq)]
pub struct IndirectRecursionError(pub Box<[Box<str>]>);

impl std::fmt::Display for IndirectRecursionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Grammar contains an indirectly recursive rule: ")?;
        for (i, symbol) in self.0.iter().enumerate() {
            if i > 0 {
                write!(f, " -> ")?;
            }
            write!(f, "{symbol}")?;
        }
        Ok(())
    }
}

#[derive(Debug, Error, Serialize, Deserialize, PartialEq, Eq)]
#[error(
    "The extra rule `{0}` matches the empty string.

Tree-sitter does not support extras that match the empty string.
"
)]
pub struct EmptyStringExtraError(pub Box<str>);

#[derive(Debug, Error, Serialize, Deserialize, PartialEq, Eq)]
#[error("Undeclared precedence '{}' in rule '{}'", self.precedence, self.rule)]
pub struct UndeclaredPrecedenceError {
    pub precedence: Box<str>,
    pub rule: Box<str>,
}

#[derive(Debug, Error, Serialize, Deserialize, PartialEq, Eq)]
#[error("Conflicting orderings for precedences {} and {}", self.precedence_1, self.precedence_2)]
pub struct ConflictingPrecedenceOrderingError {
    pub precedence_1: Box<str>,
    pub precedence_2: Box<str>,
}

pub struct PreparedGrammar {
    pub syntax_grammar: SyntaxGrammar,
    pub lexical_grammar: LexicalGrammar,
    pub inlines: InlinedProductionMap,
    pub default_aliases: AliasMap,
    pub str_pool: StrPool,
}

/// A token extracted from the input grammar but not yet expanded into the lexical NFA.
///
/// Token extraction creates this while `root` still points to the original rule in
/// the pool. [`PendingTokenExtraction::expand_and_commit`] passes them to `expand_tokens`
/// before committing the deferred syntax rewrites.
#[derive(Clone, Debug)]
pub struct LexicalToken {
    /// Generated for anon tokens, rule name for absorbed variables
    pub name: StrId,
    pub kind: VariableType,
    /// Pool root defining this token
    pub root: RuleId,
}

/// Transform an input grammar into separate components that are ready
/// for parse table construction.
pub fn prepare_grammar(
    mut g: InputGrammar,
    diagnostics: &mut Vec<Diagnostic>,
) -> PrepareGrammarResult<PreparedGrammar> {
    validate_precedences(&g)?;

    let interned_meta = intern_symbols(&mut g, diagnostics)?;
    let pending_tokens = extract_tokens(&mut g, &interned_meta)?;
    let (mut ext_meta, lexical_grammar) = pending_tokens.expand_and_commit()?;
    expand_repeats(&mut g, &mut ext_meta)?;

    let mut state = FlattenState::default();
    let mut out = ProductionStore::default();
    flatten_grammar(&g, &ext_meta, &mut state, &mut out)?;
    validate_indirect_recursion(&g, &out)?;
    validate_extras(&g, &ext_meta.extra_symbols, &lexical_grammar, &out)?;

    let default_aliases =
        extract_default_aliases(&g, &ext_meta, &lexical_grammar.variables, &mut out);
    let inlines = process_inlines(&g, &ext_meta, &lexical_grammar.variables, &mut out)?;

    let (syntax_grammar, str_pool) = assemble_syntax_grammar(g, ext_meta, out);
    Ok(PreparedGrammar {
        syntax_grammar,
        lexical_grammar,
        inlines,
        default_aliases,
        str_pool,
    })
}

/// Check for indirect recursion cycles in the grammar that can cause infinite loops while
/// parsing. An indirect recursion cycle occurs when a non-terminal can derive itself through
/// a chain of single-symbol productions (e.g., A -> B, B -> A).
fn validate_indirect_recursion(
    grammar: &InputGrammar,
    productions: &ProductionStore,
) -> Result<(), IndirectRecursionError> {
    let mut epsilon_transitions = IndexMap::new();
    for (variable, &(start, end)) in grammar.variables.iter().zip(&productions.var_prods) {
        let symbols = productions.productions[start as usize..end as usize]
            .iter()
            // Only a production containing exactly one nonterminal adds an edge
            .filter_map(|p| match productions.steps[p.step_range()] {
                [step] => step.non_terminal_index(),
                _ => None,
            })
            .map(|index| grammar.variables[usize::from(index)].name)
            // Rules that *directly* reference themselves don't cause a parsing loop.
            .filter(|&name| name != variable.name)
            .collect::<BTreeSet<_>>();
        epsilon_transitions.insert(variable.name, symbols);
    }

    let mut visited = BTreeSet::new();
    for &start_symbol in epsilon_transitions.keys() {
        let mut path = Vec::new();
        if let Some((start_idx, end_idx)) =
            get_cycle(start_symbol, &epsilon_transitions, &mut visited, &mut path)
        {
            let cycle_symbols = path[start_idx..=end_idx]
                .iter()
                .map(|&s| grammar.pool.resolve(s).to_string().into())
                .collect();
            return Err(IndirectRecursionError(cycle_symbols));
        }
    }

    Ok(())
}

/// Perform a depth-first search to detect cycles in single state transitions.
fn get_cycle(
    current: StrId,
    transitions: &IndexMap<StrId, BTreeSet<StrId>>,
    visited: &mut BTreeSet<StrId>,
    path: &mut Vec<StrId>,
) -> Option<(usize, usize)> {
    if let Some(first_idx) = path.iter().position(|s| *s == current) {
        path.push(current);
        return Some((first_idx, path.len() - 1));
    }

    if visited.contains(&current) {
        return None;
    }

    path.push(current);
    visited.insert(current);

    if let Some(next_symbols) = transitions.get(&current) {
        for next in next_symbols {
            if let Some(cycle) = get_cycle(*next, transitions, visited, path) {
                return Some(cycle);
            }
        }
    }

    path.pop();
    None
}

/// Reject extras that can match the empty string through internal tokens and rules.
/// Parsing an extra doesn't change the parse state, so the parser could keep parsing
/// an empty one at the same position.
fn validate_extras(
    grammar: &InputGrammar,
    extra_symbols: &[Symbol],
    lexical_grammar: &LexicalGrammar,
    productions: &ProductionStore,
) -> Result<(), EmptyStringExtraError> {
    let mut empty = EmptyMatches::new(lexical_grammar, productions);
    for symbol in extra_symbols {
        let (matches_empty, name) = match symbol.view() {
            SymbolView::Terminal(index) => {
                let index = usize::from(index);
                (empty.token(index), lexical_grammar.variables[index].name)
            }
            SymbolView::NonTerminal(index) => {
                let index = usize::from(index);
                (empty.rule(index), grammar.variables[index].name)
            }
            // External scanners decide whether a token consumes input, so generation
            // cannot check them.
            SymbolView::External(_) => continue,
            // INVARIANT: Token extraction only resolves extras to terminals, non-terminals,
            // and external tokens.
            SymbolView::End | SymbolView::EndOfNonTerminalExtra => unreachable!(),
        };
        if matches_empty {
            return Err(EmptyStringExtraError(grammar.pool.resolve(name).into()));
        }
    }
    Ok(())
}

/// Which tokens and rules can match the empty string, checked as the extras reach them
struct EmptyMatches<'a> {
    lexical_grammar: &'a LexicalGrammar,
    productions: &'a ProductionStore,
    /// The NFA states reached so far while checking a token
    reached: Vec<u32>,
    /// Rules that have been checked, or are being checked
    checked_rules: BitVec,
    /// The checked rules that can match the empty string
    empty_rules: BitVec,
    /// Rules found not to match while another rule was still being checked
    provisional: Vec<u32>,
    /// How many rules are being checked
    depth: u32,
}

impl<'a> EmptyMatches<'a> {
    const fn new(lexical_grammar: &'a LexicalGrammar, productions: &'a ProductionStore) -> Self {
        Self {
            lexical_grammar,
            productions,
            reached: Vec::new(),
            checked_rules: BitVec::new(),
            empty_rules: BitVec::new(),
            provisional: Vec::new(),
            depth: 0,
        }
    }

    fn symbol(&mut self, symbol: Symbol) -> bool {
        match symbol.view() {
            SymbolView::Terminal(index) => self.token(usize::from(index)),
            SymbolView::NonTerminal(index) => self.rule(usize::from(index)),
            // External token nullability is unknown. Only reject empty matches
            // established by the internal grammar.
            SymbolView::External(_) => false,
            // INVARIANT: Flattening never leaves an `End` step in a production, and
            // `EndOfNonTerminalExtra` only appears in parse table lookaheads.
            SymbolView::End | SymbolView::EndOfNonTerminalExtra => unreachable!(),
        }
    }

    /// Whether the token's NFA can reach an accept state without consuming a character
    fn token(&mut self, index: usize) -> bool {
        self.reached.clear();
        self.reached
            .push(self.lexical_grammar.variables[index].start_state);
        let mut i = 0;
        while let Some(&id) = self.reached.get(i) {
            match &self.lexical_grammar.nfa.states[id as usize] {
                NfaState::Accept { .. } => return true,
                NfaState::Split(left, right) => {
                    for next in [left, right] {
                        if !self.reached.contains(next) {
                            self.reached.push(*next);
                        }
                    }
                }
                NfaState::Advance { .. } => {}
            }
            i += 1;
        }
        false
    }

    /// Whether every step of one of the rule's productions can match the empty string.
    ///
    /// A rule that's still being checked counts as not matching, which cuts cycles. If it
    /// turns out to match, answers found while it was open are dropped and rechecked.
    fn rule(&mut self, index: usize) -> bool {
        if self.checked_rules.len() == 0 {
            let rules = self.productions.var_prods.len();
            self.checked_rules.resize(rules, false);
            self.empty_rules.resize(rules, false);
        }
        if !self.checked_rules[index] {
            self.checked_rules.set(index, true);
            let since = self.provisional.len();
            self.depth += 1;
            let (start, end) = self.productions.var_prods[index];
            let empty = self.productions.productions[start as usize..end as usize]
                .iter()
                .any(|p| {
                    self.productions.steps[p.step_range()]
                        .iter()
                        .all(|step| self.symbol(step.symbol()))
                });
            self.depth -= 1;
            if empty {
                self.empty_rules.set(index, true);
                // These may have only failed because this rule was still open
                for rule in self.provisional.drain(since..) {
                    self.checked_rules.set(rule as usize, false);
                }
            } else if self.depth > 0 {
                self.provisional.push(index as u32);
            }
        }
        self.empty_rules[index]
    }
}

/// Check that all of the named precedences used in the grammar are declared
/// within the `precedences` lists, and also that there are no conflicting
/// precedence orderings declared in those lists.
fn validate_precedences(grammar: &InputGrammar) -> ValidatePrecedenceResult<()> {
    let display = |e: &PrecedenceEntry| match *e {
        PrecedenceEntry::Name(sid) => format!("'{}'", grammar.pool.resolve(sid)),
        PrecedenceEntry::Symbol(sid) => format!("$.{}", grammar.pool.resolve(sid)),
    };
    let cmp = |a: PrecedenceEntry, b: PrecedenceEntry| match (a, b) {
        (PrecedenceEntry::Name(a), PrecedenceEntry::Name(b))
        | (PrecedenceEntry::Symbol(a), PrecedenceEntry::Symbol(b)) => {
            grammar.pool.resolve(a).cmp(grammar.pool.resolve(b))
        }
        (PrecedenceEntry::Name(_), PrecedenceEntry::Symbol(_)) => Ordering::Less,
        (PrecedenceEntry::Symbol(_), PrecedenceEntry::Name(_)) => Ordering::Greater,
    };

    // For any two precedence names `a` and `b`, if `a` comes before `b`
    // in some list, then it cannot come *after* `b` in any list.
    let mut pairs = FxHashMap::default();
    for list in &grammar.precedence_orderings {
        for (i, mut entry1) in list.iter().copied().enumerate() {
            for mut entry2 in list.iter().copied().skip(i + 1) {
                if entry1 == entry2 {
                    continue;
                }
                let mut ordering = Ordering::Greater;
                if cmp(entry1, entry2).is_gt() {
                    ordering = Ordering::Less;
                    mem::swap(&mut entry1, &mut entry2);
                }
                match pairs.entry((entry1, entry2)) {
                    hash_map::Entry::Vacant(e) => {
                        e.insert(ordering);
                    }
                    hash_map::Entry::Occupied(e) => {
                        if e.get() != &ordering {
                            Err(ConflictingPrecedenceOrderingError {
                                precedence_1: display(&entry1).into(),
                                precedence_2: display(&entry2).into(),
                            })?;
                        }
                    }
                }
            }
        }
    }

    let precedence_names = grammar
        .precedence_orderings
        .iter()
        .flatten()
        .filter_map(|p| match *p {
            PrecedenceEntry::Name(sid) => Some(sid),
            PrecedenceEntry::Symbol(_) => None,
        })
        .collect::<FxHashSet<_>>();

    let mut stack = Vec::new();
    for variable in &grammar.variables {
        stack.clear();
        stack.push(variable.root);
        while let Some(id) = stack.pop() {
            match grammar.pool.node(id) {
                Rule::Repeat(inner) => stack.push(inner),
                Rule::Seq(range) | Rule::Choice(range) => {
                    stack.extend_from_slice(grammar.pool.child_slice(range));
                }
                Rule::Metadata { params, rule } => {
                    if let Precedence::Name(sid) = grammar.pool.params(params).precedence
                        && !precedence_names.contains(&sid)
                    {
                        Err(UndeclaredPrecedenceError {
                            precedence: grammar.pool.resolve(sid).to_string().into(),
                            rule: grammar.pool.resolve(variable.name).to_string().into(),
                        })?;
                    }
                    stack.push(rule);
                }
                _ => {}
            }
        }
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        grammars::{ProductionStep, Variable, VariableType},
        rules::{RuleId, RulePool, Symbol},
    };

    #[test]
    fn test_validate_precedences_with_undeclared_precedences() {
        let mut pool = RulePool::default();

        // v1: seq(prec_left('b', "w"), prec('c', "x"))
        let v1 = {
            let w = leaf(&mut pool, "w");
            let left = prec_left(&mut pool, "b", w);
            let x = leaf(&mut pool, "x");
            let right = prec(&mut pool, "c", x);
            pool.seq(&[left, right])
        };
        // v2: repeat(choice(prec_left('omg', "y"), prec('c', "z")))
        let v2 = {
            let y = leaf(&mut pool, "y");
            let left = prec_left(&mut pool, "omg", y);
            let z = leaf(&mut pool, "z");
            let right = prec(&mut pool, "c", z);
            let choice = pool.choice(&[left, right]);
            pool.repeat(choice)
        };
        let v1_name = pool.intern("v1");
        let v2_name = pool.intern("v2");
        let precedence_orderings = vec![
            vec![name_entry(&mut pool, "a"), name_entry(&mut pool, "b")],
            vec![
                name_entry(&mut pool, "b"),
                name_entry(&mut pool, "c"),
                name_entry(&mut pool, "d"),
            ],
        ];

        let grammar = InputGrammar {
            variables: vec![
                Variable {
                    name: v1_name,
                    root: v1,
                },
                Variable {
                    name: v2_name,
                    root: v2,
                },
            ],
            precedence_orderings,
            pool,
            ..Default::default()
        };

        assert_eq!(
            validate_precedences(&grammar).unwrap_err(),
            ValidatePrecedenceError::Undeclared(UndeclaredPrecedenceError {
                precedence: "omg".to_string().into(),
                rule: "v2".to_string().into()
            })
        );
    }

    #[test]
    fn test_validate_precedences_with_conflicting_order() {
        let mut pool = RulePool::default();
        let precedence_orderings = vec![
            vec![name_entry(&mut pool, "a"), name_entry(&mut pool, "b")],
            vec![
                name_entry(&mut pool, "b"),
                name_entry(&mut pool, "c"),
                name_entry(&mut pool, "a"),
            ],
        ];
        let grammar = InputGrammar {
            pool,
            precedence_orderings,
            ..Default::default()
        };

        assert_eq!(
            validate_precedences(&grammar).unwrap_err(),
            ValidatePrecedenceError::Ordering(ConflictingPrecedenceOrderingError {
                precedence_1: "'a'".to_string().into(),
                precedence_2: "'b'".to_string().into()
            })
        );
    }

    #[test]
    fn test_validate_indirect_recursion() {
        // a -> b -> a
        let case1 = build_grammar(|p| {
            let b_ref = named(p, "b");
            let x = leaf(p, "x");
            let a = p.choice(&[b_ref, x]);
            let a_ref = named(p, "a");
            let b = p.prec(Precedence::Integer(1), a_ref);
            vec![
                Variable {
                    name: p.intern("a"),
                    root: a,
                },
                Variable {
                    name: p.intern("b"),
                    root: b,
                },
            ]
        });
        // A direct self-reference is allowed.
        let case2 = build_grammar(|p| {
            let a = named(p, "a");
            vec![Variable {
                name: p.intern("a"),
                root: a,
            }]
        });
        // b -> c -> d -> b, entered from a non-cycle start rule.
        let case3 = build_grammar(|p| {
            let x = leaf(p, "x");
            let c_ref = named(p, "c");
            let d_ref = named(p, "d");
            let b_ref = named(p, "b");
            vec![
                Variable {
                    name: p.intern("a"),
                    root: x,
                },
                Variable {
                    name: p.intern("b"),
                    root: c_ref,
                },
                Variable {
                    name: p.intern("c"),
                    root: d_ref,
                },
                Variable {
                    name: p.intern("d"),
                    root: b_ref,
                },
            ]
        });
        // b -> c -> b, through `seq(optional('|'), $.b, repeat(seq('|', $.b)))`
        let case4 = build_grammar(|p| {
            let a = {
                let b = named(p, "b");
                let assign = leaf(p, ":=");
                p.seq(&[b, assign])
            };
            let b = {
                let x = leaf(p, "x");
                let c = named(p, "c");
                p.choice(&[x, c])
            };
            let c = {
                let pipe = leaf(p, "|");
                let blank = p.blank();
                let leading_pipe = p.choice(&[pipe, blank]);
                let b = named(p, "b");
                let rest = {
                    let pipe = leaf(p, "|");
                    let b = named(p, "b");
                    let item = p.seq(&[pipe, b]);
                    let items = p.repeat(item);
                    let blank = p.blank();
                    p.choice(&[items, blank])
                };
                p.seq(&[leading_pipe, b, rest])
            };
            vec![
                Variable {
                    name: p.intern("a"),
                    root: a,
                },
                Variable {
                    name: p.intern("b"),
                    root: b,
                },
                Variable {
                    name: p.intern("c"),
                    root: c,
                },
            ]
        });

        let err1 = IndirectRecursionError(["a".into(), "b".into(), "a".into()].into());
        let err3 = IndirectRecursionError(["b".into(), "c".into(), "d".into(), "b".into()].into());
        let err4 = IndirectRecursionError(["b".into(), "c".into(), "b".into()].into());

        for (g, expected) in [
            (case1, Some(err1)),
            (case2, None),
            (case3, Some(err3)),
            (case4, Some(err4)),
        ] {
            assert_eq!(
                prepare_grammar(g, &mut Vec::new()).err(),
                expected.map(PrepareGrammarError::from)
            );
        }
    }

    #[test]
    fn test_validate_extras() {
        // `source: 'a'` followed by `rules`, with `comment` as the only extra
        fn grammar(
            rules: impl FnOnce(&mut RulePool) -> Vec<(&'static str, RuleId)>,
        ) -> InputGrammar {
            let mut grammar = build_grammar(|p| {
                let source = leaf(p, "a");
                let rules = rules(p);
                std::iter::once(("source", source))
                    .chain(rules)
                    .map(|(name, root)| Variable {
                        name: p.intern(name),
                        root,
                    })
                    .collect()
            });
            let extra = named(&mut grammar.pool, "comment");
            grammar.extra_roots.push(extra);
            grammar
        }

        for (grammar, matches_empty) in [
            // A token
            (grammar(|p| vec![("comment", pattern(p, ".*"))]), true),
            // A non-terminal whose only step is a token
            (
                grammar(|p| {
                    let content = pattern(p, ".*");
                    vec![("comment", p.seq(&[content]))]
                }),
                true,
            ),
            // A non-terminal with an empty production
            (
                grammar(|p| {
                    let hash = leaf(p, "#");
                    let content = pattern(p, ".*");
                    let comment = p.seq(&[hash, content]);
                    let blank = p.blank();
                    vec![("comment", p.choice(&[comment, blank]))]
                }),
                true,
            ),
            // A non-terminal that matches it through another one
            (
                grammar(|p| {
                    let comment = {
                        let hashes = pattern(p, "#*");
                        let body = named(p, "_body");
                        p.seq(&[hashes, body])
                    };
                    let content = pattern(p, ".*");
                    vec![("comment", comment), ("_body", p.seq(&[content]))]
                }),
                true,
            ),
            // A non-terminal that matches it through rules that reach each other
            (
                grammar(|p| {
                    let comment = {
                        let hashes = pattern(p, "#*");
                        let a = named(p, "a");
                        let b = named(p, "b");
                        let bangs = pattern(p, "!*");
                        p.seq(&[hashes, a, b, bangs])
                    };
                    let a = {
                        let b = named(p, "b");
                        let xs = pattern(p, "x*");
                        let b_xs = p.seq(&[b, xs]);
                        let zs = pattern(p, "z*");
                        p.choice(&[b_xs, zs])
                    };
                    let b = {
                        let a = named(p, "a");
                        let ws = pattern(p, "w*");
                        p.seq(&[a, ws])
                    };
                    vec![("comment", comment), ("a", a), ("b", b)]
                }),
                true,
            ),
            // A nullable first token is safe when a later step consumes input
            (
                grammar(|p| {
                    let hashes = pattern(p, "#*");
                    let hash = leaf(p, "#");
                    vec![("comment", p.seq(&[hashes, hash]))]
                }),
                false,
            ),
            // These have to consume the `#`
            (
                grammar(|p| {
                    let hash = leaf(p, "#");
                    let content = pattern(p, ".*");
                    let comment = p.seq(&[hash, content]);
                    vec![("comment", p.token(comment))]
                }),
                false,
            ),
            (
                grammar(|p| {
                    let hash = leaf(p, "#");
                    let content = pattern(p, ".*");
                    vec![("comment", p.seq(&[hash, content]))]
                }),
                false,
            ),
        ] {
            assert_eq!(
                prepare_grammar(grammar, &mut Vec::new()).err(),
                matches_empty
                    .then(|| PrepareGrammarError::from(EmptyStringExtraError("comment".into())))
            );
        }
    }

    #[test]
    fn test_validate_extras_with_shared_nullable_rules() {
        let mut grammar = build_grammar(|p| {
            let source = leaf(p, "a");
            let first = {
                let hashes = pattern(p, "#*");
                let a = named(p, "a");
                let bang = leaf(p, "!");
                p.seq(&[hashes, a, bang])
            };
            let second = {
                let ats = pattern(p, "@*");
                let b = named(p, "b");
                p.seq(&[ats, b])
            };
            let a = {
                let b = named(p, "b");
                let xs = pattern(p, "x*");
                let b_xs = p.seq(&[b, xs]);
                let zs = pattern(p, "z*");
                p.choice(&[b_xs, zs])
            };
            let b = {
                let a = named(p, "a");
                let ws = pattern(p, "w*");
                p.seq(&[a, ws])
            };
            [
                ("source", source),
                ("first", first),
                ("second", second),
                ("a", a),
                ("b", b),
            ]
            .into_iter()
            .map(|(name, root)| Variable {
                name: p.intern(name),
                root,
            })
            .collect()
        });
        for name in ["first", "second"] {
            let extra = named(&mut grammar.pool, name);
            grammar.extra_roots.push(extra);
        }

        // Checking the first extra reaches the nullable cycle, but its `!` makes it safe.
        // The same memo must still identify the second extra as nullable.
        assert_eq!(
            prepare_grammar(grammar, &mut Vec::new()).err(),
            Some(PrepareGrammarError::ValidateExtras(EmptyStringExtraError(
                "second".into()
            )))
        );
    }

    #[test]
    fn test_nullable_syntactic_tokens_and_anonymous_extras() {
        let mut grammar = build_grammar(|p| {
            let quote = leaf(p, "\"");
            let content = pattern(p, "[^\"]*");
            let source = p.seq(&[quote, content, quote]);
            vec![Variable {
                name: p.intern("source"),
                root: source,
            }]
        });
        let whitespace = pattern(&mut grammar.pool, "\\s*");
        grammar.extra_roots.push(whitespace);

        // Both tokens can match empty, but neither is shifted as an extra symbol.
        assert!(prepare_grammar(grammar, &mut Vec::new()).is_ok());
    }

    #[test]
    fn test_token_body_shared_with_syntax() {
        let grammar = build_grammar(|p| {
            let a = leaf(p, "a");
            let b = leaf(p, "b");
            let shared = p.seq(&[a, b]);
            let token = p.token(shared);
            let program = {
                let t = named(p, "t");
                let x = named(p, "x");
                p.seq(&[t, x])
            };

            vec![
                Variable {
                    name: p.intern("program"),
                    root: program,
                },
                Variable {
                    name: p.intern("t"),
                    root: token,
                },
                Variable {
                    name: p.intern("x"),
                    root: shared,
                },
            ]
        });

        let prepared = prepare_grammar(grammar, &mut Vec::new()).unwrap();

        let syntax_variables = prepared
            .syntax_grammar
            .variables
            .iter()
            .map(|variable| (prepared.str_pool.resolve(variable.name), variable.kind))
            .collect::<Vec<_>>();
        assert_eq!(
            syntax_variables,
            [("program", VariableType::Named), ("x", VariableType::Named),]
        );

        let lexical_variables = prepared
            .lexical_grammar
            .variables
            .iter()
            .map(|variable| {
                (
                    prepared.str_pool.resolve(variable.name),
                    variable.kind,
                    variable.implicit_precedence,
                    variable.start_state,
                )
            })
            .collect::<Vec<_>>();
        assert_eq!(
            lexical_variables,
            [
                ("t", VariableType::Named, 0, 2),
                ("a", VariableType::Anonymous, 2, 4),
                ("b", VariableType::Anonymous, 2, 6),
            ]
        );
    }

    #[test]
    fn test_token_body_shared_with_syntax_reversed() {
        let grammar = build_grammar(|p| {
            let a = leaf(p, "a");
            let b = leaf(p, "b");
            let shared = p.seq(&[a, b]);
            let token = p.token(shared);
            let program = {
                let x = named(p, "x");
                let t = named(p, "t");
                p.seq(&[x, t])
            };

            vec![
                Variable {
                    name: p.intern("program"),
                    root: program,
                },
                Variable {
                    name: p.intern("x"),
                    root: shared,
                },
                Variable {
                    name: p.intern("t"),
                    root: token,
                },
            ]
        });

        let prepared = prepare_grammar(grammar, &mut Vec::new()).unwrap();

        let syntax_variables = prepared
            .syntax_grammar
            .variables
            .iter()
            .map(|variable| (prepared.str_pool.resolve(variable.name), variable.kind))
            .collect::<Vec<_>>();
        assert_eq!(
            syntax_variables,
            [("program", VariableType::Named), ("x", VariableType::Named),]
        );

        let lexical_variables = prepared
            .lexical_grammar
            .variables
            .iter()
            .map(|variable| {
                (
                    prepared.str_pool.resolve(variable.name),
                    variable.kind,
                    variable.implicit_precedence,
                    variable.start_state,
                )
            })
            .collect::<Vec<_>>();
        assert_eq!(
            lexical_variables,
            [
                ("a", VariableType::Anonymous, 2, 1),
                ("b", VariableType::Anonymous, 2, 3),
                ("t", VariableType::Named, 0, 6),
            ]
        );
    }

    #[test]
    fn test_separator_body_shared_with_syntax() {
        let mut pool = RulePool::default();
        let a = leaf(&mut pool, "a");
        let b = leaf(&mut pool, "b");
        let shared = pool.seq(&[a, b]);
        let program = pool.intern("program");

        let grammar = InputGrammar {
            variables: vec![Variable {
                name: program,
                root: shared,
            }],
            extra_roots: vec![shared],
            pool,
            ..Default::default()
        };

        let prepared = prepare_grammar(grammar, &mut Vec::new()).unwrap();

        let syntax_variables = prepared
            .syntax_grammar
            .variables
            .iter()
            .map(|variable| (prepared.str_pool.resolve(variable.name), variable.kind))
            .collect::<Vec<_>>();
        assert_eq!(syntax_variables, [("program", VariableType::Named)]);

        let lexical_variables = prepared
            .lexical_grammar
            .variables
            .iter()
            .map(|variable| {
                (
                    prepared.str_pool.resolve(variable.name),
                    variable.kind,
                    variable.implicit_precedence,
                    variable.start_state,
                )
            })
            .collect::<Vec<_>>();
        assert_eq!(
            lexical_variables,
            [
                ("a", VariableType::Anonymous, 2, 5),
                ("b", VariableType::Anonymous, 2, 11),
            ]
        );

        assert_eq!(prepared.syntax_grammar.extra_symbols, [] as [Symbol; 0]);
    }

    #[test]
    fn test_shared_extra_symbol_is_renumbered_once() {
        let mut pool = RulePool::default();

        let target_ref = named(&mut pool, "target");
        let program = {
            let kw = named(&mut pool, "kw");
            let keep = named(&mut pool, "keep");
            pool.seq(&[kw, keep, target_ref])
        };
        let kw = leaf(&mut pool, "keyword");
        let keep = {
            let k = leaf(&mut pool, "k");
            let e = leaf(&mut pool, "e");
            pool.seq(&[k, e])
        };
        let target = {
            let t = leaf(&mut pool, "t");
            let g = leaf(&mut pool, "g");
            pool.seq(&[t, g])
        };

        let grammar = InputGrammar {
            variables: vec![
                Variable {
                    name: pool.intern("program"),
                    root: program,
                },
                Variable {
                    name: pool.intern("kw"),
                    root: kw,
                },
                Variable {
                    name: pool.intern("keep"),
                    root: keep,
                },
                Variable {
                    name: pool.intern("target"),
                    root: target,
                },
            ],
            extra_roots: vec![target_ref],
            pool,
            ..Default::default()
        };

        let prepared = prepare_grammar(grammar, &mut Vec::new()).unwrap();

        let syntax_variables = prepared
            .syntax_grammar
            .variables
            .iter()
            .map(|variable| (prepared.str_pool.resolve(variable.name), variable.kind))
            .collect::<Vec<_>>();
        assert_eq!(
            syntax_variables,
            [
                ("program", VariableType::Named),
                ("keep", VariableType::Named),
                ("target", VariableType::Named),
            ]
        );

        let lexical_variables = prepared
            .lexical_grammar
            .variables
            .iter()
            .map(|variable| {
                (
                    prepared.str_pool.resolve(variable.name),
                    variable.kind,
                    variable.implicit_precedence,
                    variable.start_state,
                )
            })
            .collect::<Vec<_>>();
        assert_eq!(
            lexical_variables,
            [
                ("kw", VariableType::Named, 2, 7),
                ("k", VariableType::Anonymous, 2, 9),
                ("e", VariableType::Anonymous, 2, 11),
                ("t", VariableType::Anonymous, 2, 13),
                ("g", VariableType::Anonymous, 2, 15),
            ]
        );

        assert_eq!(
            prepared.syntax_grammar.extra_symbols,
            [Symbol::non_terminal(2)]
        );
    }

    #[test]
    fn test_shared_syntax_subtree_is_renumbered_once() {
        let grammar = build_grammar(|p| {
            let pair = {
                let thing = named(p, "thing");
                let dash = leaf(p, "-");
                p.seq(&[thing, dash])
            };
            let item_b = {
                let semicolon = leaf(p, ";");
                p.seq(&[pair, semicolon])
            };
            let program = {
                let kw = named(p, "kw");
                let item_a = named(p, "item_a");
                let item_b = named(p, "item_b");
                p.seq(&[kw, item_a, item_b])
            };
            let kw = leaf(p, "keyword");
            let thing = {
                let t = leaf(p, "t");
                let u = leaf(p, "u");
                p.seq(&[t, u])
            };

            vec![
                Variable {
                    name: p.intern("program"),
                    root: program,
                },
                Variable {
                    name: p.intern("kw"),
                    root: kw,
                },
                Variable {
                    name: p.intern("item_a"),
                    root: pair,
                },
                Variable {
                    name: p.intern("item_b"),
                    root: item_b,
                },
                Variable {
                    name: p.intern("thing"),
                    root: thing,
                },
            ]
        });

        let prepared = prepare_grammar(grammar, &mut Vec::new()).unwrap();

        let expected_steps = [
            ProductionStep::pack(
                Symbol::non_terminal(3),
                Precedence::None,
                None,
                None,
                None,
                0,
            ),
            ProductionStep::pack(Symbol::terminal(1), Precedence::None, None, None, None, 0),
        ];

        let production_ids = prepared.syntax_grammar.variable_prod_ids(1);
        assert_eq!(production_ids.len(), 1);

        let production = prepared.syntax_grammar.production(production_ids.start);
        assert_eq!(production.steps, expected_steps);
        assert_eq!(production.dynamic_precedence, 0);
    }

    fn named(pool: &mut RulePool, name: &str) -> RuleId {
        let id = pool.intern(name);
        pool.named_symbol(id)
    }
    fn leaf(pool: &mut RulePool, s: &str) -> RuleId {
        let id = pool.intern(s);
        pool.string(id)
    }
    fn pattern(pool: &mut RulePool, value: &str) -> RuleId {
        let value = pool.intern(value);
        let flags = pool.intern("");
        pool.pattern(value, flags)
    }
    fn prec(pool: &mut RulePool, name: &str, content: RuleId) -> RuleId {
        let p = Precedence::Name(pool.intern(name));
        pool.prec(p, content)
    }
    fn prec_left(pool: &mut RulePool, name: &str, content: RuleId) -> RuleId {
        let p = Precedence::Name(pool.intern(name));
        pool.prec_left(p, content)
    }
    fn name_entry(pool: &mut RulePool, name: &str) -> PrecedenceEntry {
        PrecedenceEntry::Name(pool.intern(name))
    }

    fn build_grammar(build: impl FnOnce(&mut RulePool) -> Vec<Variable>) -> InputGrammar {
        let mut pool = RulePool::default();
        let variables = build(&mut pool);
        InputGrammar {
            pool,
            variables,
            ..Default::default()
        }
    }
}
