import pytest
from pydantic import ValidationError

from openapi_python_client.schema import OpenAPI
from openapi_python_client.schema.untrusted_string import UntrustedString


@pytest.mark.parametrize(
    "version, valid",
    [
        ("abc", False),
        ("1", False),
        ("2.0", False),
        ("3.0.0", True),
        ("3.1.1", True),
        ("3.2.0", False),
        ("4.0.0", False),
    ],
)
def test_validate_version(version, valid):
    data = {"openapi": version, "info": {"title": "test", "version": ""}, "paths": {}}
    if valid:
        OpenAPI.model_validate(data)
    else:
        with pytest.raises(ValidationError):
            OpenAPI.model_validate(data)


def test_parse_with_callback():
    data = {
        "openapi": "3.0.1",
        "info": {"title": "API with Callback", "version": ""},
        "paths": {
            "/create": {
                "post": {
                    "responses": {"200": {"description": "Success"}},
                    "callbacks": {"event": {"callback": {"post": {"responses": {"200": {"description": "Success"}}}}}},
                }
            }
        },
    }

    open_api = OpenAPI.model_validate(data)
    create_endpoint = open_api.paths[UntrustedString("/create")]
    assert "200" in create_endpoint.post.responses
    assert "200" in create_endpoint.post.callbacks["event"]["callback"].post.responses
