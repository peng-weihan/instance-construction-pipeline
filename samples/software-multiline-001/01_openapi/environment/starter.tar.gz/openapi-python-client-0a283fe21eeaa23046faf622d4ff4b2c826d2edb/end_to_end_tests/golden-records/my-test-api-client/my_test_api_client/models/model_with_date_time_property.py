from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ModelWithDateTimeProperty")


@_attrs_define
class ModelWithDateTimeProperty:
    """
    Attributes:
        datetime_ (datetime.datetime | Unset):
    """

    datetime_: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        datetime_: str | Unset = UNSET
        if not isinstance(self.datetime_, Unset):
            datetime_ = self.datetime_.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if datetime_ is not UNSET:
            field_dict["datetime"] = datetime_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _datetime_ = d.pop("datetime", UNSET)
        datetime_: datetime.datetime | Unset
        if isinstance(_datetime_, Unset):
            datetime_ = UNSET
        else:
            datetime_ = datetime.datetime.fromisoformat(_datetime_)

        model_with_date_time_property = cls(
            datetime_=datetime_,
        )

        model_with_date_time_property.additional_properties = d
        return model_with_date_time_property

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
