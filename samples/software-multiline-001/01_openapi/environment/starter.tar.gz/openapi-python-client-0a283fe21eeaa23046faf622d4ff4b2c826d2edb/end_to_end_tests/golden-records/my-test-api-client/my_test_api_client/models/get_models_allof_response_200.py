from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.a_model import AModel
    from ..models.extended import Extended


T = TypeVar("T", bound="GetModelsAllofResponse200")


@_attrs_define
class GetModelsAllofResponse200:
    """
    Attributes:
        aliased (AModel | Unset): A Model for testing all the ways custom objects can be used
        extended (Extended | Unset):
        model (AModel | Unset): A Model for testing all the ways custom objects can be used
    """

    aliased: AModel | Unset = UNSET
    extended: Extended | Unset = UNSET
    model: AModel | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        aliased: dict[str, Any] | Unset = UNSET
        if not isinstance(self.aliased, Unset):
            aliased = self.aliased.to_dict()

        extended: dict[str, Any] | Unset = UNSET
        if not isinstance(self.extended, Unset):
            extended = self.extended.to_dict()

        model: dict[str, Any] | Unset = UNSET
        if not isinstance(self.model, Unset):
            model = self.model.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if aliased is not UNSET:
            field_dict["aliased"] = aliased
        if extended is not UNSET:
            field_dict["extended"] = extended
        if model is not UNSET:
            field_dict["model"] = model

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.a_model import AModel  # noqa: PLC0415
        from ..models.extended import Extended  # noqa: PLC0415

        d = dict(src_dict)
        _aliased = d.pop("aliased", UNSET)
        aliased: AModel | Unset
        if isinstance(_aliased, Unset):
            aliased = UNSET
        else:
            aliased = AModel.from_dict(_aliased)

        _extended = d.pop("extended", UNSET)
        extended: Extended | Unset
        if isinstance(_extended, Unset):
            extended = UNSET
        else:
            extended = Extended.from_dict(_extended)

        _model = d.pop("model", UNSET)
        model: AModel | Unset
        if isinstance(_model, Unset):
            model = UNSET
        else:
            model = AModel.from_dict(_model)

        get_models_allof_response_200 = cls(
            aliased=aliased,
            extended=extended,
            model=model,
        )

        get_models_allof_response_200.additional_properties = d
        return get_models_allof_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
