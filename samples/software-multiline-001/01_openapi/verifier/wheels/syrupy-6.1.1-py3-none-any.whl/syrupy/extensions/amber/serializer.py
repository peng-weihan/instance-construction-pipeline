import collections
import dataclasses
import inspect
from abc import ABC, abstractmethod
from collections import OrderedDict
from collections.abc import Callable, Generator, Iterable
from pathlib import Path
from types import (
    FunctionType,
    GeneratorType,
    MappingProxyType,
)
from typing import (
    TYPE_CHECKING,
    Any,
    NamedTuple,
    Optional,
)

from syrupy.constants import (
    SYMBOL_ELLIPSIS,
    TEXT_ENCODING,
)
from syrupy.data import (
    Snapshot,
    SnapshotCollection,
)
from syrupy.utils import (
    exclusive_file_lock,
    replace_atomic,
    snapshot_file_lock_enabled,
)

if TYPE_CHECKING:
    from syrupy.types import (
        PropertyFilter,
        PropertyMatcher,
        PropertyName,
        PropertyPath,
        SerializableData,
    )

    PropertyValueFilter = Callable[["PropertyName"], bool]
    PropertyValueGetter = Callable[
        ["SerializableData", "PropertyName"], "SerializableData"
    ]
    IterableEntries = tuple[
        Iterable["PropertyName"],
        "PropertyValueGetter",
        "PropertyValueFilter | None",
    ]


class Repr:
    def __init__(self, _repr: str):
        self._repr = _repr

    def __repr__(self) -> str:
        return self._repr


def attr_getter(o: "SerializableData", p: "PropertyName") -> "SerializableData":
    return getattr(o, str(p))


def item_getter(o: "SerializableData", p: "PropertyName") -> "SerializableData":
    return o[p]


class MalformedAmberFile(Exception):
    """
    The Amber file is malformed. It should be deleted and regenerated.
    """


class MissingVersionError(Exception):
    """
    Missing Amber version marker.
    """


def removesuffix(string: str, suffix: str) -> str:
    """
    Can be replaced with str.removesuffix once Py3.8 support is dropped.
    """

    if string.endswith(suffix):
        return string[: -len(suffix)]
    return string


class AmberDataSerializerPlugin(ABC):
    """
    A Syrupy plugin for extending Amber serialization.
    """

    @classmethod
    @abstractmethod
    def is_data_serializable(cls, data: "SerializableData") -> bool:
        """
        Determine if this plugin can serialize the given data.
        """

    @classmethod
    @abstractmethod
    def serialize(cls, data: "SerializableData", **kwargs: Any) -> str:
        """
        Return the serialization method for the given data.
        """


class AmberDataSerializer:
    """
    If extending the serializer, change the VERSION property to some unique value
    for your iteration of the serializer so as to force invalidation of existing
    snapshots.
    """

    VERSION = "1"

    serializer_plugins: Iterable[type["AmberDataSerializerPlugin"]] | None = None

    _indent: str = "  "
    _max_depth: int = 99
    _marker_prefix = "# "

    class Marker:
        Version = "serializer version"
        Name = "name"
        Divider = "---"

    @classmethod
    def _default_snapshot_sort_key(cls, snapshot: "Snapshot") -> Any:
        return snapshot.name

    @classmethod
    def _snapshot_name_for_order_lookup(cls, name: str) -> str:
        """Strip trailing numeric assertion suffixes (``.1``, ``.2``, …)."""
        if "." not in name:
            return name
        base, maybe_index = name.rsplit(".", 1)
        if maybe_index.isdigit():
            return base
        return name

    @classmethod
    def snapshot_sort_key(
        cls,
        snapshot: "Snapshot",
        name_order: dict[str, int] | None = None,
    ) -> Any:
        if name_order:
            lookup = cls._snapshot_name_for_order_lookup(snapshot.name)
            if lookup in name_order:
                # Collection index, then full name for assertion-index siblings
                # (e.g. test_foo vs test_foo.1).
                return (name_order[lookup], snapshot.name)
            # Snapshots not in the current collection (e.g. orphans during merge)
            # sort after known names, still alphabetically among themselves.
            return (len(name_order), snapshot.name)
        return cls._default_snapshot_sort_key(snapshot)

    @classmethod
    def write_file(
        cls,
        snapshot_collection: "SnapshotCollection",
        merge: bool = False,
        name_order: dict[str, int] | None = None,
        *,
        file_lock: bool | None = None,
        _already_locked: bool = False,
    ) -> None:
        """
        Writes the snapshot data into the snapshot file that can be read later.

        With ``merge=True`` (the amber multi-entry path), this is a
        read-modify-write. Under pytest-xdist, multiple workers may update the
        same file concurrently. Pass ``--snapshot-file-lock`` to guard the RMW
        with an exclusive lock and replace the file atomically (#1237).
        Lock wait time defaults to 60s (``--snapshot-file-lock-timeout``).

        ``file_lock`` overrides the session/context setting when not ``None``.
        Pass ``_already_locked=True`` when the caller already holds
        :func:`~syrupy.utils.exclusive_file_lock` for this path (e.g. delete).
        """
        filepath = snapshot_collection.location
        use_file_lock = snapshot_file_lock_enabled() if file_lock is None else file_lock

        def _with_merged_collection() -> "SnapshotCollection":
            if not merge:
                return snapshot_collection
            base_snapshot = cls.read_file(filepath)
            base_snapshot.merge(snapshot_collection)
            return base_snapshot

        def _write_to(path: str, collection: "SnapshotCollection") -> None:
            with open(path, "w", encoding=TEXT_ENCODING, newline=None) as f:
                f.write(f"{cls._marker_prefix}{cls.Marker.Version}: {cls.VERSION}\n")
                for snapshot in sorted(
                    collection,
                    key=lambda s: cls.snapshot_sort_key(s, name_order),
                ):
                    snapshot_data = str(snapshot.data)
                    if snapshot_data is not None:
                        f.write(
                            f"{cls._marker_prefix}{cls.Marker.Name}: {snapshot.name}\n"
                        )
                        # Split on \n only. We avoid str.splitlines() because
                        # it also splits on \x0b, \x0c, \x1c-\x1e, \x85,
                        # \u2028, and \u2029, but the file reader (which
                        # iterates lines from the file object) only splits
                        # on \n, \r, and \r\n.
                        parts = snapshot_data.split("\n")
                        for i, part in enumerate(parts):
                            is_last = i == len(parts) - 1
                            if not is_last:
                                f.write(cls.with_indent(part + "\n", 1))
                            elif part:
                                f.write(cls.with_indent(part, 1))
                        if snapshot_data.endswith("\n"):
                            f.write(cls.with_indent("", 1))
                        f.write(f"\n{cls._marker_prefix}{cls.Marker.Divider}\n")

        if not use_file_lock:
            _write_to(filepath, _with_merged_collection())
            return

        def _atomic_write() -> None:
            tmp_filepath = f"{filepath}.tmp"
            try:
                _write_to(tmp_filepath, _with_merged_collection())
                replace_atomic(tmp_filepath, filepath)
            finally:
                # Always drop the temp file, including on KeyboardInterrupt.
                Path(tmp_filepath).unlink(missing_ok=True)

        if _already_locked:
            _atomic_write()
        else:
            with exclusive_file_lock(filepath):
                _atomic_write()

    @classmethod
    def __read_file_with_markers(
        cls, filepath: str
    ) -> Generator["Snapshot", None, None]:
        marker_offset = len(cls._marker_prefix)
        indent_len = len(cls._indent)

        test_name = None
        snapshot_data = ""
        tainted = False
        missing_version = True

        try:
            with open(filepath, encoding=TEXT_ENCODING, newline=None) as f:
                for line_no, line in enumerate(f):
                    if line.startswith(cls._marker_prefix):
                        marker_key, *marker_rest = line[marker_offset:].split(
                            ":", maxsplit=1
                        )
                        marker_key = marker_key.rstrip(" \r\n")
                        marker_value = marker_rest[0].strip() if marker_rest else None

                        if marker_key == cls.Marker.Version:
                            if line_no:
                                raise MalformedAmberFile(
                                    "Version must be specified at the top of the file."
                                )
                            if not marker_value or marker_value != cls.VERSION:
                                tainted = True
                                continue
                            missing_version = False

                        if marker_key == cls.Marker.Name:
                            if not marker_value:
                                raise MalformedAmberFile("Missing snapshot name.")

                            test_name = marker_value.strip(" \r\n")
                            continue
                        if marker_key == cls.Marker.Divider:
                            if test_name and snapshot_data:
                                yield Snapshot(
                                    name=test_name,
                                    data=removesuffix(snapshot_data, "\r\n")
                                    if snapshot_data.endswith("\r\n")
                                    else removesuffix(snapshot_data, "\n"),
                                    tainted=tainted,
                                )
                            test_name = None
                            snapshot_data = ""
                    elif test_name is not None and line.startswith(cls._indent):
                        snapshot_data += line[indent_len:]
        except FileNotFoundError:
            pass
        else:
            if missing_version:
                raise MissingVersionError

    @classmethod
    def read_file(cls, filepath: str) -> "SnapshotCollection":
        """
        Read the raw snapshot data (str) from the snapshot file into a dict
        of snapshot name to raw data. This does not attempt any deserialization
        of the snapshot data.
        """
        snapshot_collection = SnapshotCollection(location=filepath)
        try:
            for snapshot in cls.__read_file_with_markers(filepath):
                if snapshot.tainted:
                    snapshot_collection.tainted = True
                snapshot_collection.add(snapshot)
        except MissingVersionError:
            snapshot_collection.tainted = True

        return snapshot_collection

    @classmethod
    def serialize(
        cls,
        data: "SerializableData",
        *,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
    ) -> str:
        """
        After serializing, new line control characters are normalised. This is needed
        for interoperablity of snapshot matching between systems that do not use the
        same new line control characters. Example snapshots generated on windows os
        should not break when running the tests on a unix based system and vice versa.
        """
        serialized = cls._serialize(
            data, exclude=exclude, include=include, matcher=matcher
        )
        return serialized.replace("\r\n", "\n").replace("\r", "\n")

    @classmethod
    def _serialize(
        cls,
        data: "SerializableData",
        *,
        depth: int = 0,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
        path: "PropertyPath" = (),
        visited: set[Any] | None = None,
    ) -> str:
        visited = set() if visited is None else visited
        data_id = id(data)
        # Track ancestors in one shared set and unwind after recursing, instead
        # of copying the set at every node.
        already_visited = data_id in visited
        if depth > cls._max_depth or already_visited:
            data = Repr(SYMBOL_ELLIPSIS)
        elif matcher:
            data = matcher(data=data, path=path)
        if not already_visited:
            visited.add(data_id)
        try:
            serialize_method = cls._assign_serialize_method(data)
            return serialize_method(
                data=data,
                depth=depth,
                exclude=exclude,
                include=include,
                matcher=matcher,
                path=path,
                visited=visited,
            )
        finally:
            if not already_visited:
                visited.discard(data_id)

    @classmethod
    def _assign_serialize_method(cls, data: "SerializableData") -> Callable[..., str]:
        if cls.serializer_plugins:
            for plugin in cls.serializer_plugins:
                if plugin.is_data_serializable(data):
                    return plugin.serialize

        if isinstance(data, str):
            return cls.serialize_string
        elif isinstance(data, (int, float)):
            return cls.serialize_number
        elif isinstance(data, (set, frozenset)):
            return cls.serialize_set
        elif isinstance(data, (dict, MappingProxyType)):
            return cls.serialize_dict
        elif cls.__is_namedtuple(data):
            return cls.serialize_namedtuple
        elif dataclasses.is_dataclass(data) and not isinstance(data, type):
            return cls.serialize_dataclass
        elif isinstance(data, (list, tuple, GeneratorType)):
            return cls.serialize_iterable
        elif isinstance(data, FunctionType):
            return cls.serialize_function
        return cls.serialize_unknown

    @classmethod
    def serialize_number(
        cls,
        data: float,
        *,
        depth: int = 0,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
        path: "PropertyPath" = (),
        visited: set[Any] | None = None,
    ) -> str:
        return cls.__serialize_plain(data=data, depth=depth)

    @classmethod
    def serialize_string(
        cls,
        data: str,
        *,
        depth: int = 0,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
        path: "PropertyPath" = (),
        visited: set[Any] | None = None,
    ) -> str:
        if "\n" not in data and "\r" not in data:
            return cls.__serialize_plain(data=data, depth=depth)

        return cls.__serialize_lines(
            data=data,
            lines=(
                cls.with_indent(line, depth + 1 if depth else depth)
                for line in data.splitlines(keepends=True)
            ),
            depth=depth,
            open_tag="'''",
            close_tag="'''",
            include_type=False,
            ends="",
        )

    @classmethod
    def serialize_iterable(
        cls,
        data: Iterable["SerializableData"],
        *,
        depth: int = 0,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
        path: "PropertyPath" = (),
        visited: set[Any] | None = None,
    ) -> str:
        open_paren, close_paren = (None, None)
        if isinstance(data, list):
            open_paren, close_paren = ("[", "]")

        values = list(data)
        return cls.serialize_custom_iterable(
            data=data,
            resolve_entries=(range(len(values)), item_getter, None),
            open_paren=open_paren,
            close_paren=close_paren,
            depth=depth,
            exclude=exclude,
            include=include,
            matcher=matcher,
            path=path,
            visited=visited,
        )

    @classmethod
    def serialize_set(
        cls,
        data: set["SerializableData"],
        *,
        depth: int = 0,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
        path: "PropertyPath" = (),
        visited: set[Any] | None = None,
    ) -> str:
        return cls.serialize_custom_iterable(
            data=data,
            resolve_entries=(cls.sort(data), lambda _, p: p, None),
            open_paren="{",
            close_paren="}",
            depth=depth,
            exclude=exclude,
            include=include,
            matcher=matcher,
            path=path,
            visited=visited,
        )

    @classmethod
    def serialize_namedtuple(
        cls,
        data: NamedTuple,
        *,
        depth: int = 0,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
        path: "PropertyPath" = (),
        visited: set[Any] | None = None,
    ) -> str:
        return cls.serialize_custom_iterable(
            data=data,
            resolve_entries=(cls.sort(data._fields), attr_getter, None),
            separator="=",
            depth=depth,
            exclude=exclude,
            include=include,
            matcher=matcher,
            path=path,
            visited=visited,
        )

    @classmethod
    def serialize_dataclass(
        cls,
        data: Any,
        *,
        depth: int = 0,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
        path: "PropertyPath" = (),
        visited: set[Any] | None = None,
    ) -> str:
        keys = sorted(f.name for f in dataclasses.fields(data))
        return cls.serialize_custom_iterable(
            data=data,
            resolve_entries=(keys, attr_getter, None),
            separator="=",
            depth=depth,
            exclude=exclude,
            include=include,
            matcher=matcher,
            path=path,
            visited=visited,
        )

    @classmethod
    def serialize_dict(
        cls,
        data: dict["PropertyName", "SerializableData"],
        *,
        depth: int = 0,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
        path: "PropertyPath" = (),
        visited: set[Any] | None = None,
    ) -> str:
        keys = (
            data.keys() if isinstance(data, (OrderedDict,)) else cls.sort(data.keys())
        )

        return cls.serialize_custom_iterable(
            data=data,
            resolve_entries=(keys, item_getter, None),
            open_paren="{",
            close_paren="}",
            separator=": ",
            serialize_key=True,
            depth=depth,
            exclude=exclude,
            include=include,
            matcher=matcher,
            path=path,
            visited=visited,
        )

    @classmethod
    def serialize_function(
        cls,
        data: FunctionType,
        *,
        depth: int = 0,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
        path: "PropertyPath" = (),
        visited: set[Any] | None = None,
    ) -> str:
        return cls.__serialize_plain(
            data=f"{data.__qualname__}{inspect.signature(data)!s}", depth=depth
        )

    @classmethod
    def serialize_unknown(
        cls,
        data: Any,
        *,
        depth: int = 0,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
        path: "PropertyPath" = (),
        visited: set[Any] | None = None,
    ) -> str:
        if data.__class__.__repr__ != object.__repr__:
            return cls.__serialize_plain(data=data, depth=depth)

        return cls.serialize_custom_iterable(
            data=data,
            resolve_entries=(
                cls.sort(cls.object_attrs(data)),
                attr_getter,
                lambda v: not callable(v),
            ),
            depth=depth,
            separator="=",
            exclude=exclude,
            include=include,
            matcher=matcher,
            path=path,
            visited=visited,
        )

    @classmethod
    def object_attrs(cls, data: Any) -> "Iterable[str]":
        return (name for name in dir(data) if not name.startswith("_"))

    @classmethod
    def object_as_named_tuple(cls, data: Any) -> "tuple[Any, ...]":
        attr_names = list(cls.object_attrs(data))
        return collections.namedtuple(data.__class__.__name__, attr_names)(
            **{prop: getattr(data, prop) for prop in attr_names}
        )

    @classmethod
    def with_indent(cls, string: str, depth: int) -> str:
        return f"{cls._indent * depth}{string}"

    @classmethod
    def sort(cls, iterable: Iterable[Any]) -> Iterable[Any]:
        # Pre-sort by the serialized form so a natural ordering that is only
        # partial keeps a deterministic order for incomparable elements. E.g.
        # frozensets order by the subset relation, so two distinct frozensets
        # where neither is a subset of the other compare as neither < nor >;
        # the stable sort below would then leave them in hash-seeded set
        # iteration order. Totally-ordered values keep their natural order.
        values = sorted(iterable, key=cls._serialize)
        try:
            return sorted(values)
        except TypeError:
            return values

    @classmethod
    def object_type(cls, data: "SerializableData") -> str:
        return f"{data.__class__.__name__}"

    @classmethod
    def __is_namedtuple(cls, obj: Any) -> bool:
        return isinstance(obj, tuple) and all(
            isinstance(n, (str,)) for n in getattr(obj, "_fields", [None])
        )

    @classmethod
    def __serialize_plain(
        cls,
        *,
        data: "SerializableData",
        depth: int = 0,
    ) -> str:
        return cls.with_indent(repr(data), depth)

    @classmethod
    def serialize_custom_iterable(
        cls,
        *,
        data: "SerializableData",
        resolve_entries: "IterableEntries",
        open_paren: str | None = None,
        close_paren: str | None = None,
        depth: int = 0,
        exclude: Optional["PropertyFilter"] = None,
        include: Optional["PropertyFilter"] = None,
        matcher: Optional["PropertyMatcher"] = None,
        path: "PropertyPath" = (),
        separator: str | None = None,
        serialize_key: bool = False,
        visited: set[Any] | None = None,
        # Kept for backwards compatibility with serializer plugins that forward
        # extra keyword arguments. All known arguments are bound explicitly above
        # so the hot path no longer relies on this dict.
        **kwargs: Any,
    ) -> str:
        """
        Utility to serialize a custom iterable.
        """
        child_depth = depth + 1

        keys, get_value, include_value = resolve_entries
        key_values = (
            (key, get_value(data, key))
            for key in keys
            if (not exclude or not exclude(prop=key, path=path))
            and (not include or include(prop=key, path=path))
        )
        entries = (
            entry
            for entry in key_values
            if not include_value or include_value(entry[1])
        )

        def key_str(key: "PropertyName") -> str:
            if separator is None:
                return ""
            return (
                cls._serialize(
                    data=key, depth=child_depth, matcher=matcher, visited=visited
                )
                if serialize_key
                else cls.with_indent(str(key), depth=depth + 1)
            ) + separator

        def value_str(key: "PropertyName", value: "SerializableData") -> str:
            serialized = cls._serialize(
                data=value,
                depth=child_depth,
                exclude=exclude,
                include=include,
                matcher=matcher,
                path=(*path, (key, type(value))),
                visited=visited,
            )
            return serialized if separator is None else serialized.lstrip(cls._indent)

        return cls.__serialize_lines(
            data=data,
            lines=(f"{key_str(key)}{value_str(key, value)}," for key, value in entries),
            depth=depth,
            open_tag=f"({open_paren or ''}",
            close_tag=f"{close_paren or ''})",
        )

    @classmethod
    def __serialize_lines(
        cls,
        *,
        data: "SerializableData",
        lines: Iterable[str],
        open_tag: str,
        close_tag: str,
        depth: int = 0,
        include_type: bool = True,
        ends: str = "\n",
    ) -> str:
        lines = ends.join(lines)
        lines_end = "\n" if lines else ""
        maybe_obj_type = f"{cls.object_type(data)}" if include_type else ""
        formatted_open_tag = cls.with_indent(f"{maybe_obj_type}{open_tag}", depth)
        formatted_close_tag = cls.with_indent(close_tag, depth)
        return f"{formatted_open_tag}\n{lines}{lines_end}{formatted_close_tag}"


class AmberDataSerializerSorted(AmberDataSerializer):
    """
    This is an experimental serializer with known performance issues.
    """

    VERSION = f"{AmberDataSerializer.VERSION}-sorted"

    @classmethod
    def __maybe_int(cls, part: str) -> tuple[int, str | int]:
        try:
            # cast to int only if the string is the exact representation of the int
            # for example, '012' != str(int('012'))
            i = int(part)
            if str(i) == part:
                return (1, i)
            return (0, part)
        except ValueError:
            # the nested tuple is to prevent comparing a str to an int
            return (0, part)

    @classmethod
    def _default_snapshot_sort_key(cls, snapshot: "Snapshot") -> Any:
        return [cls.__maybe_int(part) for part in snapshot.name.split(".")]
