/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.extension.auth.opa;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.nio.file.Path;
import java.time.Duration;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/** Unit tests for OpaHttpClientFactory. */
public class OpaHttpClientFactoryTest {

  @TempDir Path tempDir;

  @Test
  void testCreateHttpClientWithHttpUrl() throws Exception {
    OpaAuthorizationConfig.HttpConfig httpConfig =
        ImmutableHttpConfig.builder().timeout(Duration.ofSeconds(5)).verifySsl(true).build();

    try (CloseableHttpClient client = OpaHttpClientFactory.createHttpClient(httpConfig)) {
      assertThat(client).isNotNull();
    }
  }

  @Test
  void testCreateHttpClientWithHttpsUrl() throws Exception {
    OpaAuthorizationConfig.HttpConfig httpConfig =
        ImmutableHttpConfig.builder().timeout(Duration.ofSeconds(5)).verifySsl(false).build();

    try (CloseableHttpClient client = OpaHttpClientFactory.createHttpClient(httpConfig)) {
      assertThat(client).isNotNull();
    }
  }

  @Test
  void testCreateHttpClientFailsForMissingTrustStore() {
    OpaAuthorizationConfig.HttpConfig httpConfig =
        ImmutableHttpConfig.builder()
            .timeout(Duration.ofSeconds(5))
            .verifySsl(true)
            .trustStorePath(tempDir.resolve("missing-truststore.jks"))
            .build();

    assertThatThrownBy(() -> OpaHttpClientFactory.createHttpClient(httpConfig))
        .isInstanceOf(RuntimeException.class)
        .hasMessageContaining("Failed to create HTTP client for OPA communication");
  }
}
