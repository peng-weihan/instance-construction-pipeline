/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.extension.auth.opa;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ClassicHttpRequest;
import org.apache.hc.core5.http.ClassicHttpResponse;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.HttpException;
import org.apache.hc.core5.http.io.HttpClientResponseHandler;
import org.apache.hc.core5.http.io.entity.HttpEntities;
import org.apache.hc.core5.http.message.BasicClassicHttpResponse;
import org.apache.polaris.core.auth.AuthorizationDecision;
import org.apache.polaris.core.auth.AuthorizationIntent;
import org.apache.polaris.core.auth.AuthorizationRequest;
import org.apache.polaris.core.auth.AuthorizationState;
import org.apache.polaris.core.auth.PathSegment;
import org.apache.polaris.core.auth.PolarisAuthorizableOperation;
import org.apache.polaris.core.auth.PolarisPrincipal;
import org.apache.polaris.core.auth.PolarisSecurable;
import org.apache.polaris.core.auth.RenameAuthorizationIntent;
import org.apache.polaris.core.auth.SingleTargetAuthorizationIntent;
import org.apache.polaris.core.auth.TargetlessAuthorizationIntent;
import org.apache.polaris.core.collection.AttributeMap;
import org.apache.polaris.core.collection.AttributeMap.AttributeKey;
import org.apache.polaris.core.collection.ImmutableAttributeMap;
import org.apache.polaris.core.entity.PolarisEntity;
import org.apache.polaris.core.entity.PolarisEntityConstants;
import org.apache.polaris.core.entity.PolarisEntityType;
import org.apache.polaris.core.persistence.PolarisResolvedPathWrapper;
import org.apache.polaris.core.persistence.ResolvedPolarisEntity;
import org.apache.polaris.core.persistence.resolver.PolarisResolutionManifest;
import org.apache.polaris.extension.auth.opa.token.BearerTokenProvider;
import org.apache.polaris.extension.auth.opa.token.StaticBearerTokenProvider;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for OpaPolarisAuthorizer including basic functionality and bearer token authentication
 */
public class OpaPolarisAuthorizerTest {

  @Test
  void serializesBasicOpaInput() throws Exception {
    // Capture the request body for verification
    final String[] capturedRequestBody = new String[1];

    HttpServer server = createServerWithRequestCapture(capturedRequestBody);
    try {
      // Use the dynamically assigned port from the local server
      URI policyUri =
          URI.create(
              "http://localhost:" + server.getAddress().getPort() + "/v1/data/polaris/allow");
      OpaPolarisAuthorizer authorizer =
          new OpaPolarisAuthorizer(
              policyUri,
              HttpClients.createDefault(),
              JsonMapper.builder().build(),
              null,
              null,
              "test-realm");

      PolarisPrincipal principal =
          PolarisPrincipal.of(
              "eve",
              ImmutableAttributeMap.builder()
                  .put(new AttributeKey<>("department"), "finance")
                  .build(),
              Set.of("auditor"));

      PolarisResolvedPathWrapper target = new PolarisResolvedPathWrapper(List.of());
      PolarisResolvedPathWrapper secondary = new PolarisResolvedPathWrapper(List.of());

      assertThatNoException()
          .isThrownBy(
              () ->
                  authorizer
                      .authorize(
                          new AuthorizationState(mock(PolarisResolutionManifest.class)),
                          new AuthorizationRequest(
                              principal,
                              authorizationIntents(
                                  PolarisAuthorizableOperation.LOAD_VIEW,
                                  List.of(target),
                                  List.of(secondary))))
                      .throwIfDenied());

      // Parse and verify JSON structure from captured request
      ObjectMapper mapper = JsonMapper.builder().build();
      JsonNode root = mapper.readTree(capturedRequestBody[0]);
      assertThat(root.has("input")).as("Root should have 'input' field").isTrue();
      var input = root.get("input");
      assertThat(input.has("actor")).as("Input should have 'actor' field").isTrue();
      assertThat(input.has("action")).as("Input should have 'action' field").isTrue();
      assertThat(input.has("resource")).as("Input should have 'resource' field").isTrue();
      assertThat(input.has("context")).as("Input should have 'context' field").isTrue();

      // Verify realm is included for tenant isolation
      assertThat(input.get("context").has("realm")).as("context should contain realm").isTrue();
      assertThat(input.get("context").get("realm").asText()).isEqualTo("test-realm");
    } finally {
      server.stop(0);
    }
  }

  @Test
  void serializesHierarchicalTarget() throws Exception {
    // Capture the request body for verification
    final String[] capturedRequestBody = new String[1];

    HttpServer server = createServerWithRequestCapture(capturedRequestBody);
    try {
      URI policyUri =
          URI.create(
              "http://localhost:" + server.getAddress().getPort() + "/v1/data/polaris/allow");
      OpaPolarisAuthorizer authorizer =
          new OpaPolarisAuthorizer(
              policyUri,
              HttpClients.createDefault(),
              JsonMapper.builder().build(),
              null,
              null,
              "prod-realm");

      // Set up a realistic principal
      PolarisPrincipal principal =
          PolarisPrincipal.of(
              "alice",
              ImmutableAttributeMap.builder()
                  .put(new AttributeKey<>("department"), "analytics")
                  .put(new AttributeKey<>("level"), "senior")
                  .build(),
              Set.of("data_engineer", "analyst"));

      // Create a hierarchical resource structure: catalog.namespace.table
      // Create catalog entity using builder pattern
      PolarisEntity catalogEntity =
          new PolarisEntity.Builder()
              .setName("prod_catalog")
              .setType(PolarisEntityType.CATALOG)
              .setId(100L)
              .setCatalogId(100L)
              .setParentId(0L)
              .setCreateTimestamp(System.currentTimeMillis())
              .build();

      // Create namespace entity using builder pattern
      PolarisEntity namespaceEntity =
          new PolarisEntity.Builder()
              .setName("sales_data")
              .setType(PolarisEntityType.NAMESPACE)
              .setId(200L)
              .setCatalogId(100L)
              .setParentId(100L)
              .setCreateTimestamp(System.currentTimeMillis())
              .build();

      // Create table entity using builder pattern
      PolarisEntity tableEntity =
          new PolarisEntity.Builder()
              .setName("customer_orders")
              .setType(PolarisEntityType.TABLE_LIKE)
              .setId(300L)
              .setCatalogId(100L)
              .setParentId(200L)
              .setCreateTimestamp(System.currentTimeMillis())
              .build();

      // Create hierarchical path: catalog -> namespace -> table
      // Build a realistic resolved path using ResolvedPolarisEntity objects
      List<ResolvedPolarisEntity> resolvedPath =
          List.of(
              createResolvedEntity(catalogEntity),
              createResolvedEntity(namespaceEntity),
              createResolvedEntity(tableEntity));
      PolarisResolvedPathWrapper tablePath = new PolarisResolvedPathWrapper(resolvedPath);

      assertThatNoException()
          .isThrownBy(
              () ->
                  authorizer
                      .authorize(
                          new AuthorizationState(mock(PolarisResolutionManifest.class)),
                          new AuthorizationRequest(
                              principal,
                              authorizationIntents(
                                  PolarisAuthorizableOperation.LOAD_TABLE,
                                  List.of(tablePath),
                                  null)))
                      .throwIfDenied());

      // Parse and verify the complete JSON structure
      ObjectMapper mapper = JsonMapper.builder().build();
      JsonNode root = mapper.readTree(capturedRequestBody[0]);

      // Verify top-level structure
      assertThat(root.has("input")).as("Root should have 'input' field").isTrue();
      var input = root.get("input");
      assertThat(input.has("actor")).as("Input should have 'actor' field").isTrue();
      assertThat(input.has("action")).as("Input should have 'action' field").isTrue();
      assertThat(input.has("resource")).as("Input should have 'resource' field").isTrue();
      assertThat(input.has("context")).as("Input should have 'context' field").isTrue();

      // Verify realm for tenant isolation
      assertThat(input.get("context").has("realm")).isTrue();
      assertThat(input.get("context").get("realm").asText()).isEqualTo("prod-realm");

      // Verify actor details
      var actor = input.get("actor");
      assertThat(actor.has("principal")).as("Actor should have 'principal' field").isTrue();
      assertThat(actor.get("principal").asText()).isEqualTo("alice");
      assertThat(actor.has("roles")).as("Actor should have 'roles' field").isTrue();
      assertThat(actor.get("roles").isArray()).as("Roles should be an array").isTrue();
      assertThat(actor.get("roles").size()).isEqualTo(2);

      // Verify action
      var action = input.get("action");
      assertThat(action.asText()).isEqualTo("LOAD_TABLE");

      // Verify resource structure - this is the key part for hierarchical resources
      var resource = input.get("resource");
      assertThat(resource.has("targets")).as("Resource should have 'targets' field").isTrue();

      var targets = resource.get("targets");
      assertThat(targets.isArray()).as("Targets should be an array").isTrue();
      assertThat(targets.size()).as("Should have exactly one target").isEqualTo(1);

      JsonNode expectedTarget =
          mapper.readTree(
              """
              {
                "type": "TABLE_LIKE",
                "name": "customer_orders",
                "parents": [
                  {"type": "CATALOG", "name": "prod_catalog", "parents": []},
                  {"type": "NAMESPACE", "name": "sales_data", "parents": []}
                ]
              }
              """);
      assertThat(targets.get(0)).isEqualTo(expectedTarget);

      // Secondaries field should be omitted when empty (NON_EMPTY serialization)
      assertThat(resource.has("secondaries"))
          .as("Secondaries should be omitted when empty")
          .isFalse();
    } finally {
      server.stop(0);
    }
  }

  @Test
  void serializesMultiLevelNamespaceTarget() throws Exception {
    // Capture the request body for verification
    final String[] capturedRequestBody = new String[1];

    HttpServer server = createServerWithRequestCapture(capturedRequestBody);
    try {
      URI policyUri =
          URI.create(
              "http://localhost:" + server.getAddress().getPort() + "/v1/data/polaris/allow");
      OpaPolarisAuthorizer authorizer =
          new OpaPolarisAuthorizer(
              policyUri,
              HttpClients.createDefault(),
              JsonMapper.builder().build(),
              null,
              null,
              "analytics-realm");

      // Set up a realistic principal
      PolarisPrincipal principal =
          PolarisPrincipal.of(
              "bob",
              ImmutableAttributeMap.builder()
                  .put(new AttributeKey<>("team"), "ml")
                  .put(new AttributeKey<>("project"), "forecasting")
                  .build(),
              Set.of("data_scientist", "analyst"));

      // Create a multi-level namespace structure: catalog.department.team.table
      // Create catalog entity
      PolarisEntity catalogEntity =
          new PolarisEntity.Builder()
              .setName("analytics_catalog")
              .setType(PolarisEntityType.CATALOG)
              .setId(100L)
              .setCatalogId(100L)
              .setParentId(0L)
              .setCreateTimestamp(System.currentTimeMillis())
              .build();

      // Create first-level namespace entity (department)
      PolarisEntity departmentEntity =
          new PolarisEntity.Builder()
              .setName("engineering")
              .setType(PolarisEntityType.NAMESPACE)
              .setId(200L)
              .setCatalogId(100L)
              .setParentId(100L)
              .setCreateTimestamp(System.currentTimeMillis())
              .build();

      // Create second-level namespace entity (team)
      PolarisEntity teamEntity =
          new PolarisEntity.Builder()
              .setName("machine_learning")
              .setType(PolarisEntityType.NAMESPACE)
              .setId(300L)
              .setCatalogId(100L)
              .setParentId(200L)
              .setCreateTimestamp(System.currentTimeMillis())
              .build();

      // Create table entity
      PolarisEntity tableEntity =
          new PolarisEntity.Builder()
              .setName("feature_store")
              .setType(PolarisEntityType.TABLE_LIKE)
              .setId(400L)
              .setCatalogId(100L)
              .setParentId(300L)
              .setCreateTimestamp(System.currentTimeMillis())
              .build();

      // Create hierarchical path: catalog -> department -> team -> table
      List<ResolvedPolarisEntity> resolvedPath =
          List.of(
              createResolvedEntity(catalogEntity),
              createResolvedEntity(departmentEntity),
              createResolvedEntity(teamEntity),
              createResolvedEntity(tableEntity));
      PolarisResolvedPathWrapper tablePath = new PolarisResolvedPathWrapper(resolvedPath);

      assertThatNoException()
          .isThrownBy(
              () ->
                  authorizer
                      .authorize(
                          new AuthorizationState(mock(PolarisResolutionManifest.class)),
                          new AuthorizationRequest(
                              principal,
                              authorizationIntents(
                                  PolarisAuthorizableOperation.LOAD_TABLE,
                                  List.of(tablePath),
                                  null)))
                      .throwIfDenied());

      // Parse and verify the complete JSON structure
      ObjectMapper mapper = JsonMapper.builder().build();
      JsonNode root = mapper.readTree(capturedRequestBody[0]);

      // Verify top-level structure
      assertThat(root.has("input")).as("Root should have 'input' field").isTrue();
      var input = root.get("input");
      assertThat(input.has("actor")).as("Input should have 'actor' field").isTrue();
      assertThat(input.has("action")).as("Input should have 'action' field").isTrue();
      assertThat(input.has("resource")).as("Input should have 'resource' field").isTrue();
      assertThat(input.has("context")).as("Input should have 'context' field").isTrue();

      // Verify realm for tenant isolation
      assertThat(input.get("context").has("realm")).isTrue();
      assertThat(input.get("context").get("realm").asText()).isEqualTo("analytics-realm");

      // Verify actor details
      var actor = input.get("actor");
      assertThat(actor.get("principal").asText()).isEqualTo("bob");
      assertThat(actor.get("roles").size()).isEqualTo(2);

      // Verify action
      var action = input.get("action");
      assertThat(action.asText()).isEqualTo("LOAD_TABLE");

      // Verify resource structure with multi-level namespace hierarchy
      var resource = input.get("resource");
      var targets = resource.get("targets");
      assertThat(targets.size()).as("Should have exactly one target").isEqualTo(1);

      var target = targets.get(0);
      // Verify the target entity (table) details
      assertThat(target.get("type").asText())
          .as("Target type should be TABLE_LIKE")
          .isEqualTo("TABLE_LIKE");
      assertThat(target.get("name").asText())
          .as("Target name should be feature_store")
          .isEqualTo("feature_store");

      // Verify the multi-level hierarchical parents array
      assertThat(target.has("parents")).as("Target should have 'parents' field").isTrue();
      var parents = target.get("parents");
      assertThat(parents.isArray()).as("Parents should be an array").isTrue();
      assertThat(parents.size())
          .as("Should have 3 parents (catalog, department, team)")
          .isEqualTo(3);

      // Verify catalog parent (first in the hierarchy)
      var catalogParent = parents.get(0);
      assertThat(catalogParent.get("type").asText())
          .as("First parent should be catalog")
          .isEqualTo("CATALOG");
      assertThat(catalogParent.get("name").asText())
          .as("Catalog name should be analytics_catalog")
          .isEqualTo("analytics_catalog");

      // Verify department namespace parent (second in the hierarchy)
      var departmentParent = parents.get(1);
      assertThat(departmentParent.get("type").asText())
          .as("Second parent should be namespace")
          .isEqualTo("NAMESPACE");
      assertThat(departmentParent.get("name").asText())
          .as("Department name should be engineering")
          .isEqualTo("engineering");

      // Verify team namespace parent (third in the hierarchy)
      var teamParent = parents.get(2);
      assertThat(teamParent.get("type").asText())
          .as("Third parent should be namespace")
          .isEqualTo("NAMESPACE");
      assertThat(teamParent.get("name").asText())
          .as("Team name should be machine_learning")
          .isEqualTo("machine_learning");

      // Secondaries field should be omitted when empty (NON_EMPTY serialization)
      assertThat(resource.has("secondaries"))
          .as("Secondaries should be omitted when empty")
          .isFalse();
    } finally {
      server.stop(0);
    }
  }

  @Test
  void authorizeHandlesEmptyTargetsAndSecondaries() throws Exception {
    HttpServer server = createServerWithAllowResponse();
    try {
      URI policyUri =
          URI.create(
              "http://localhost:" + server.getAddress().getPort() + "/v1/data/polaris/allow");
      OpaPolarisAuthorizer authorizer =
          new OpaPolarisAuthorizer(
              policyUri,
              HttpClients.createDefault(),
              JsonMapper.builder().build(),
              null,
              null,
              "test-realm");

      PolarisPrincipal principal =
          PolarisPrincipal.of("alice", AttributeMap.EMPTY, Set.of("admin"));

      PolarisResolvedPathWrapper target = new PolarisResolvedPathWrapper(List.of());
      PolarisResolvedPathWrapper secondary = new PolarisResolvedPathWrapper(List.of());

      assertThatNoException()
          .isThrownBy(
              () ->
                  authorizer
                      .authorize(
                          new AuthorizationState(mock(PolarisResolutionManifest.class)),
                          new AuthorizationRequest(
                              principal,
                              authorizationIntents(
                                  PolarisAuthorizableOperation.CREATE_CATALOG,
                                  List.of(target),
                                  List.of(secondary))))
                      .throwIfDenied());

      // Test multiple targets
      PolarisResolvedPathWrapper target1 = new PolarisResolvedPathWrapper(List.of());
      PolarisResolvedPathWrapper target2 = new PolarisResolvedPathWrapper(List.of());
      List<PolarisResolvedPathWrapper> targets = List.of(target1, target2);
      List<PolarisResolvedPathWrapper> secondaries = List.of();

      assertThatNoException()
          .isThrownBy(
              () ->
                  authorizer
                      .authorize(
                          new AuthorizationState(mock(PolarisResolutionManifest.class)),
                          new AuthorizationRequest(
                              principal,
                              authorizationIntents(
                                  PolarisAuthorizableOperation.LOAD_VIEW, targets, secondaries)))
                      .throwIfDenied());
    } finally {
      server.stop(0);
    }
  }

  @Test
  public void testCreateWithHttpsAndBearerToken() {
    // Test that OpaPolarisAuthorizer can be created with HTTPS URLs and bearer tokens
    BearerTokenProvider tokenProvider = new StaticBearerTokenProvider("test-bearer-token");
    URI policyUri = URI.create("http://opa.example.com:8181/v1/data/polaris/allow");
    OpaPolarisAuthorizer authorizer =
        new OpaPolarisAuthorizer(
            policyUri,
            HttpClients.createDefault(),
            JsonMapper.builder().build(),
            tokenProvider,
            null,
            "test-realm");

    assertThat(authorizer).isNotNull();
  }

  @Test
  public void testBearerTokenIsAddedToHttpRequest() {
    URI policyUri = URI.create("http://opa.example.com:8181/v1/data/polaris/allow");
    HttpEntity mockEntity = HttpEntities.create("{\"result\":{\"allow\":true}}");
    @SuppressWarnings("resource")
    ClassicHttpResponse mockResponse = new BasicClassicHttpResponse(200);
    mockResponse.setEntity(mockEntity);

    BearerTokenProvider tokenProvider = new StaticBearerTokenProvider("test-bearer-token");
    OpaPolarisAuthorizer authorizer =
        new OpaPolarisAuthorizer(
            policyUri,
            mock(CloseableHttpClient.class),
            JsonMapper.builder().build(),
            tokenProvider,
            null,
            "test-realm") {
          @Override
          <T> T httpClientExecute(
              ClassicHttpRequest request, HttpClientResponseHandler<? extends T> responseHandler)
              throws HttpException, IOException {
            // Verify the Authorization header with static bearer token
            verifyAuthorizationHeader(request, "test-bearer-token");

            return responseHandler.handleResponse(mockResponse);
          }
        };

    PolarisPrincipal mockPrincipal =
        PolarisPrincipal.of("test-user", AttributeMap.EMPTY, Collections.emptySet());

    PolarisAuthorizableOperation mockOperation = PolarisAuthorizableOperation.LOAD_TABLE;
    PolarisResolvedPathWrapper target = null;
    PolarisResolvedPathWrapper secondary = null;
    assertThatNoException()
        .isThrownBy(
            () -> {
              authorizer
                  .authorize(
                      new AuthorizationState(mock(PolarisResolutionManifest.class)),
                      new AuthorizationRequest(
                          mockPrincipal,
                          authorizationIntents(
                              mockOperation,
                              target == null ? null : List.of(target),
                              secondary == null ? null : List.of(secondary))))
                  .throwIfDenied();
            });
  }

  @Test
  public void testBearerTokenFromBearerTokenProvider() {
    // Mock HTTP client and response
    HttpEntity mockEntity = HttpEntities.create("{\"result\":{\"allow\":true}}");
    @SuppressWarnings("resource")
    ClassicHttpResponse mockResponse = new BasicClassicHttpResponse(200);
    mockResponse.setEntity(mockEntity);

    // Create token provider that returns a dynamic token
    BearerTokenProvider tokenProvider = () -> "dynamic-token-12345";
    URI policyUri = URI.create("http://opa.example.com:8181/v1/data/polaris/allow");
    // Create authorizer with the token provider instead of static token
    OpaPolarisAuthorizer authorizer =
        new OpaPolarisAuthorizer(
            policyUri,
            mock(CloseableHttpClient.class),
            JsonMapper.builder().build(),
            tokenProvider,
            null,
            "test-realm") {
          @Override
          <T> T httpClientExecute(
              ClassicHttpRequest request, HttpClientResponseHandler<? extends T> responseHandler)
              throws HttpException, IOException {
            // Verify the Authorization header with bearer token from provider
            verifyAuthorizationHeader(request, "dynamic-token-12345");

            return responseHandler.handleResponse(mockResponse);
          }
        };

    // Create mock principal and entities
    PolarisPrincipal mockPrincipal =
        PolarisPrincipal.of("test-user", AttributeMap.EMPTY, Collections.emptySet());

    PolarisAuthorizableOperation mockOperation = PolarisAuthorizableOperation.LOAD_TABLE;
    PolarisResolvedPathWrapper target = null;
    PolarisResolvedPathWrapper secondary = null;

    // Execute authorization (should not throw since we mocked allow=true)
    assertThatNoException()
        .isThrownBy(
            () -> {
              authorizer
                  .authorize(
                      new AuthorizationState(mock(PolarisResolutionManifest.class)),
                      new AuthorizationRequest(
                          mockPrincipal,
                          authorizationIntents(
                              mockOperation,
                              target == null ? null : List.of(target),
                              secondary == null ? null : List.of(secondary))))
                  .throwIfDenied();
            });
  }

  @Test
  void resolveAuthorizationInputsResolvesAll() {
    // resolveAll() is intentionally used for compatibility and is expected
    // to be narrowed in a future refactoring.
    OpaPolarisAuthorizer authorizer =
        new OpaPolarisAuthorizer(
            URI.create("http://opa.example.com:8181/v1/data/polaris/allow"),
            mock(CloseableHttpClient.class),
            JsonMapper.builder().build(),
            null,
            null,
            "test-realm");
    PolarisResolutionManifest resolutionManifest = mock(PolarisResolutionManifest.class);
    AuthorizationState authzState = new AuthorizationState(resolutionManifest);
    PolarisPrincipal principal = PolarisPrincipal.of("alice", AttributeMap.EMPTY, Set.of("role-1"));

    authorizer.resolveAuthorizationInputs(authzState, requestWithCatalogTarget(principal));

    verify(resolutionManifest).resolveAll();
  }

  @Test
  void authorizeUsesIntentInputsAndAllows() throws Exception {
    final String[] capturedRequestBody = new String[1];
    PolarisPrincipal principal = PolarisPrincipal.of("alice", AttributeMap.EMPTY, Set.of("role-1"));
    AuthorizationRequest request = requestWithCatalogTarget(principal);
    HttpEntity mockEntity = HttpEntities.create("{\"result\":{\"allow\":true}}");
    @SuppressWarnings("resource")
    ClassicHttpResponse mockResponse = new BasicClassicHttpResponse(200);
    mockResponse.setEntity(mockEntity);
    PolarisResolutionManifest resolutionManifest = mock(PolarisResolutionManifest.class);
    AuthorizationState authzState = new AuthorizationState(resolutionManifest);

    OpaPolarisAuthorizer authorizer =
        new OpaPolarisAuthorizer(
            URI.create("http://opa.example.com:8181/v1/data/polaris/allow"),
            mock(CloseableHttpClient.class),
            JsonMapper.builder().build(),
            null,
            null,
            "test-realm") {
          @Override
          <T> T httpClientExecute(
              ClassicHttpRequest request, HttpClientResponseHandler<? extends T> responseHandler)
              throws HttpException, IOException {
            capturedRequestBody[0] =
                new String(request.getEntity().getContent().readAllBytes(), StandardCharsets.UTF_8);
            return responseHandler.handleResponse(mockResponse);
          }
        };

    AuthorizationDecision decision = authorizer.authorize(authzState, request);
    ObjectMapper mapper = JsonMapper.builder().build();
    JsonNode root = mapper.readTree(capturedRequestBody[0]);

    assertThat(decision.isAllowed()).isTrue();
    assertThat(root.path("input").path("action").asText()).isEqualTo("GET_CATALOG");
    JsonNode expectedTarget =
        mapper.readTree(
            """
            {
              "type": "CATALOG",
              "name": "catalog-1",
              "parents": []
            }
            """);
    JsonNode target = root.path("input").path("resource").path("targets").get(0);
    assertThat(target).isEqualTo(expectedTarget);
    assertThat(target.path("parents").isEmpty()).isTrue();
    assertThat(root.path("input").path("resource").toString()).doesNotContain("\"type\":\"ROOT\"");
  }

  @Test
  void authorizeDeniesWhenOpaDenies() {
    PolarisPrincipal principal = PolarisPrincipal.of("alice", AttributeMap.EMPTY, Set.of("role-1"));
    AuthorizationRequest request = requestWithCatalogTarget(principal);
    HttpEntity mockEntity = HttpEntities.create("{\"result\":{\"allow\":false}}");
    @SuppressWarnings("resource")
    ClassicHttpResponse mockResponse = new BasicClassicHttpResponse(200);
    mockResponse.setEntity(mockEntity);
    PolarisResolutionManifest resolutionManifest = mock(PolarisResolutionManifest.class);
    AuthorizationState authzState = new AuthorizationState(resolutionManifest);

    OpaPolarisAuthorizer authorizer =
        new OpaPolarisAuthorizer(
            URI.create("http://opa.example.com:8181/v1/data/polaris/allow"),
            mock(CloseableHttpClient.class),
            JsonMapper.builder().build(),
            null,
            null,
            "test-realm") {
          @Override
          <T> T httpClientExecute(
              ClassicHttpRequest request, HttpClientResponseHandler<? extends T> responseHandler)
              throws HttpException, IOException {
            return responseHandler.handleResponse(mockResponse);
          }
        };

    AuthorizationDecision decision = authorizer.authorize(authzState, request);

    assertThat(decision.isAllowed()).isFalse();
    assertThat(decision.getMessage()).hasValue("OPA denied authorization");
  }

  @Test
  void authorizeIncludesStructuredParentsFromSecurable() throws Exception {
    final String[] capturedRequestBody = new String[1];
    AuthorizationRequest request =
        new AuthorizationRequest(
            PolarisPrincipal.of("alice", AttributeMap.EMPTY, Set.of("role-1")),
            List.of(
                new SingleTargetAuthorizationIntent(
                    PolarisAuthorizableOperation.LOAD_TABLE,
                    PolarisSecurable.of(
                        new PathSegment(PolarisEntityType.CATALOG, "catalog1"),
                        new PathSegment(PolarisEntityType.NAMESPACE, "ns1"),
                        new PathSegment(PolarisEntityType.NAMESPACE, "ns2"),
                        new PathSegment(PolarisEntityType.TABLE_LIKE, "table1")))));
    HttpEntity mockEntity = HttpEntities.create("{\"result\":{\"allow\":true}}");
    @SuppressWarnings("resource")
    ClassicHttpResponse mockResponse = new BasicClassicHttpResponse(200);
    mockResponse.setEntity(mockEntity);
    PolarisResolutionManifest resolutionManifest = mock(PolarisResolutionManifest.class);
    AuthorizationState authzState = new AuthorizationState(resolutionManifest);

    OpaPolarisAuthorizer authorizer =
        new OpaPolarisAuthorizer(
            URI.create("http://opa.example.com:8181/v1/data/polaris/allow"),
            mock(CloseableHttpClient.class),
            JsonMapper.builder().build(),
            null,
            null,
            "catalog-realm") {
          @Override
          <T> T httpClientExecute(
              ClassicHttpRequest request, HttpClientResponseHandler<? extends T> responseHandler)
              throws HttpException, IOException {
            capturedRequestBody[0] =
                new String(request.getEntity().getContent().readAllBytes(), StandardCharsets.UTF_8);
            return responseHandler.handleResponse(mockResponse);
          }
        };

    AuthorizationDecision decision = authorizer.authorize(authzState, request);
    ObjectMapper mapper = JsonMapper.builder().build();
    JsonNode root = mapper.readTree(capturedRequestBody[0]);

    assertThat(decision.isAllowed()).isTrue();
    assertThat(root.path("input").path("context").get("realm").asText()).isEqualTo("catalog-realm");
    JsonNode expectedTarget =
        mapper.readTree(
            """
            {
              "type": "TABLE_LIKE",
              "name": "table1",
              "parents": [
                {"type": "CATALOG", "name": "catalog1", "parents": []},
                {"type": "NAMESPACE", "name": "ns1", "parents": []},
                {"type": "NAMESPACE", "name": "ns2", "parents": []}
              ]
            }
            """);
    assertThat(root.path("input").path("resource").path("targets").get(0))
        .isEqualTo(expectedTarget);
  }

  @Test
  void authorizeCatalogTargetOmitsRootParent() throws Exception {
    final String[] capturedRequestBody = new String[1];

    HttpServer server = createServerWithRequestCapture(capturedRequestBody);
    try {
      URI policyUri =
          URI.create(
              "http://localhost:" + server.getAddress().getPort() + "/v1/data/polaris/allow");
      OpaPolarisAuthorizer authorizer =
          new OpaPolarisAuthorizer(
              policyUri,
              HttpClients.createDefault(),
              JsonMapper.builder().build(),
              null,
              null,
              "test-realm");

      PolarisEntity rootEntity =
          new PolarisEntity.Builder()
              .setName(PolarisEntityConstants.getRootContainerName())
              .setType(PolarisEntityType.ROOT)
              .setId(0L)
              .setCatalogId(0L)
              .setParentId(0L)
              .setCreateTimestamp(System.currentTimeMillis())
              .build();
      PolarisEntity catalogEntity =
          new PolarisEntity.Builder()
              .setName("catalog-1")
              .setType(PolarisEntityType.CATALOG)
              .setId(100L)
              .setCatalogId(100L)
              .setParentId(0L)
              .setCreateTimestamp(System.currentTimeMillis())
              .build();

      assertThatNoException()
          .isThrownBy(
              () ->
                  authorizer
                      .authorize(
                          new AuthorizationState(mock(PolarisResolutionManifest.class)),
                          new AuthorizationRequest(
                              PolarisPrincipal.of(
                                  "root", AttributeMap.EMPTY, Set.of("service_admin")),
                              authorizationIntents(
                                  PolarisAuthorizableOperation.GET_CATALOG,
                                  List.of(
                                      new PolarisResolvedPathWrapper(
                                          List.of(
                                              createResolvedEntity(rootEntity),
                                              createResolvedEntity(catalogEntity)))),
                                  null)))
                      .throwIfDenied());

      ObjectMapper mapper = JsonMapper.builder().build();
      JsonNode root = mapper.readTree(capturedRequestBody[0]);
      JsonNode target = root.path("input").path("resource").path("targets").get(0);
      JsonNode expectedTarget =
          mapper.readTree(
              """
              {
                "type": "CATALOG",
                "name": "catalog-1",
                "parents": []
              }
              """);
      assertThat(target).isEqualTo(expectedTarget);
    } finally {
      server.stop(0);
    }
  }

  @Test
  void authorizeRootScopedOperationOmitsRootTarget() throws Exception {
    final String[] capturedRequestBody = new String[1];

    HttpServer server = createServerWithRequestCapture(capturedRequestBody);
    try {
      URI policyUri =
          URI.create(
              "http://localhost:" + server.getAddress().getPort() + "/v1/data/polaris/allow");
      OpaPolarisAuthorizer authorizer =
          new OpaPolarisAuthorizer(
              policyUri,
              HttpClients.createDefault(),
              JsonMapper.builder().build(),
              null,
              null,
              "test-realm");

      PolarisEntity rootEntity =
          new PolarisEntity.Builder()
              .setName(PolarisEntityConstants.getRootContainerName())
              .setType(PolarisEntityType.ROOT)
              .setId(0L)
              .setCatalogId(0L)
              .setParentId(0L)
              .setCreateTimestamp(System.currentTimeMillis())
              .build();

      assertThatNoException()
          .isThrownBy(
              () ->
                  authorizer
                      .authorize(
                          new AuthorizationState(mock(PolarisResolutionManifest.class)),
                          new AuthorizationRequest(
                              PolarisPrincipal.of(
                                  "root", AttributeMap.EMPTY, Set.of("service_admin")),
                              authorizationIntents(
                                  PolarisAuthorizableOperation.LIST_CATALOGS,
                                  List.of(
                                      new PolarisResolvedPathWrapper(
                                          List.of(createResolvedEntity(rootEntity)))),
                                  null)))
                      .throwIfDenied());

      ObjectMapper mapper = JsonMapper.builder().build();
      JsonNode root = mapper.readTree(capturedRequestBody[0]);
      assertThat(root.path("input").path("resource").path("targets").isMissingNode()).isTrue();
    } finally {
      server.stop(0);
    }
  }

  @Test
  void authorizeRenameIncludesTargetAndSecondaryPaths() throws Exception {
    final String[] capturedRequestBody = new String[1];
    HttpEntity mockEntity = HttpEntities.create("{\"result\":{\"allow\":true}}");
    @SuppressWarnings("resource")
    ClassicHttpResponse mockResponse = new BasicClassicHttpResponse(200);
    mockResponse.setEntity(mockEntity);

    PolarisResolutionManifest resolutionManifest = mock(PolarisResolutionManifest.class);
    AuthorizationState authzState = new AuthorizationState(resolutionManifest);

    AuthorizationRequest request =
        new AuthorizationRequest(
            PolarisPrincipal.of("alice", AttributeMap.EMPTY, Set.of("role-1")),
            List.of(
                new RenameAuthorizationIntent(
                    PolarisAuthorizableOperation.RENAME_TABLE,
                    PolarisSecurable.of(
                        new PathSegment(PolarisEntityType.CATALOG, "catalog1"),
                        new PathSegment(PolarisEntityType.NAMESPACE, "src_ns"),
                        new PathSegment(PolarisEntityType.TABLE_LIKE, "src_tbl")),
                    PolarisSecurable.of(
                        new PathSegment(PolarisEntityType.CATALOG, "catalog1"),
                        new PathSegment(PolarisEntityType.NAMESPACE, "dst_ns"),
                        new PathSegment(PolarisEntityType.TABLE_LIKE, "dst_tbl")))));

    OpaPolarisAuthorizer authorizer =
        new OpaPolarisAuthorizer(
            URI.create("http://opa.example.com:8181/v1/data/polaris/allow"),
            mock(CloseableHttpClient.class),
            JsonMapper.builder().build(),
            null,
            null,
            "test-realm") {
          @Override
          <T> T httpClientExecute(
              ClassicHttpRequest request, HttpClientResponseHandler<? extends T> responseHandler)
              throws HttpException, IOException {
            capturedRequestBody[0] =
                new String(request.getEntity().getContent().readAllBytes(), StandardCharsets.UTF_8);
            return responseHandler.handleResponse(mockResponse);
          }
        };

    AuthorizationDecision decision = authorizer.authorize(authzState, request);
    ObjectMapper mapper = JsonMapper.builder().build();
    JsonNode root = mapper.readTree(capturedRequestBody[0]);

    assertThat(decision.isAllowed()).isTrue();

    JsonNode expectedSource =
        mapper.readTree(
            """
            {
              "type": "TABLE_LIKE",
              "name": "src_tbl",
              "parents": [
                {"type": "CATALOG", "name": "catalog1", "parents": []},
                {"type": "NAMESPACE", "name": "src_ns", "parents": []}
              ]
            }
            """);
    assertThat(root.path("input").path("resource").path("targets").get(0))
        .isEqualTo(expectedSource);

    JsonNode expectedDestination =
        mapper.readTree(
            """
            {
              "type": "TABLE_LIKE",
              "name": "dst_tbl",
              "parents": [
                {"type": "CATALOG", "name": "catalog1", "parents": []},
                {"type": "NAMESPACE", "name": "dst_ns", "parents": []}
              ]
            }
            """);
    assertThat(root.path("input").path("resource").path("secondaries").get(0))
        .isEqualTo(expectedDestination);
  }

  @Test
  void authorizeSingleOperationMultiIntentRequestEvaluatesSequentially() throws Exception {
    final List<String> capturedRequestBodies = new ArrayList<>();
    HttpEntity mockEntity = HttpEntities.create("{\"result\":{\"allow\":true}}");
    @SuppressWarnings("resource")
    ClassicHttpResponse mockResponse = new BasicClassicHttpResponse(200);
    mockResponse.setEntity(mockEntity);

    PolarisResolutionManifest resolutionManifest = mock(PolarisResolutionManifest.class);
    AuthorizationState authzState = new AuthorizationState(resolutionManifest);
    PolarisPrincipal principal = PolarisPrincipal.of("alice", AttributeMap.EMPTY, Set.of("role-1"));

    OpaPolarisAuthorizer authorizer =
        new OpaPolarisAuthorizer(
            URI.create("http://opa.example.com:8181/v1/data/polaris/allow"),
            mock(CloseableHttpClient.class),
            JsonMapper.builder().build(),
            null,
            null,
            "test-realm") {
          @Override
          <T> T httpClientExecute(
              ClassicHttpRequest request, HttpClientResponseHandler<? extends T> responseHandler)
              throws HttpException, IOException {
            capturedRequestBodies.add(
                new String(
                    request.getEntity().getContent().readAllBytes(), StandardCharsets.UTF_8));
            return responseHandler.handleResponse(mockResponse);
          }
        };

    AuthorizationDecision decision =
        authorizer.authorize(
            authzState,
            new AuthorizationRequest(
                principal,
                List.of(
                    new SingleTargetAuthorizationIntent(
                        PolarisAuthorizableOperation.GET_CATALOG,
                        PolarisSecurable.of(
                            new PathSegment(PolarisEntityType.CATALOG, "catalog-1"))),
                    new SingleTargetAuthorizationIntent(
                        PolarisAuthorizableOperation.GET_CATALOG,
                        PolarisSecurable.of(
                            new PathSegment(PolarisEntityType.CATALOG, "catalog-2"))))));

    ObjectMapper mapper = JsonMapper.builder().build();
    assertThat(decision.isAllowed()).isTrue();
    assertThat(capturedRequestBodies).hasSize(2);
    JsonNode firstRoot = mapper.readTree(capturedRequestBodies.get(0));
    JsonNode secondRoot = mapper.readTree(capturedRequestBodies.get(1));
    assertThat(firstRoot.path("input").path("action").asText()).isEqualTo("GET_CATALOG");
    assertThat(secondRoot.path("input").path("action").asText()).isEqualTo("GET_CATALOG");
    JsonNode expectedFirstTargets =
        mapper.readTree(
            """
            [
              {
                "type": "CATALOG",
                "name": "catalog-1",
                "parents": []
              }
            ]
            """);
    JsonNode expectedSecondTargets =
        mapper.readTree(
            """
            [
              {
                "type": "CATALOG",
                "name": "catalog-2",
                "parents": []
              }
            ]
            """);
    assertThat(firstRoot.path("input").path("resource").path("targets"))
        .isEqualTo(expectedFirstTargets);
    assertThat(secondRoot.path("input").path("resource").path("targets"))
        .isEqualTo(expectedSecondTargets);
    assertThat(firstRoot.path("input").path("resource").path("secondaries")).isEmpty();
    assertThat(secondRoot.path("input").path("resource").path("secondaries")).isEmpty();
  }

  @Test
  void authorizeUpdateTableMultiIntentRequestEvaluatesSequentially() {
    final int[] requestCount = new int[1];
    HttpEntity mockEntity = HttpEntities.create("{\"result\":{\"allow\":true}}");
    @SuppressWarnings("resource")
    ClassicHttpResponse mockResponse = new BasicClassicHttpResponse(200);
    mockResponse.setEntity(mockEntity);

    PolarisResolutionManifest resolutionManifest = mock(PolarisResolutionManifest.class);
    AuthorizationState authzState = new AuthorizationState(resolutionManifest);
    PolarisPrincipal principal = PolarisPrincipal.of("alice", AttributeMap.EMPTY, Set.of("role-1"));
    PolarisSecurable tableTarget =
        PolarisSecurable.of(
            new PathSegment(PolarisEntityType.CATALOG, "catalog-1"),
            new PathSegment(PolarisEntityType.NAMESPACE, "ns"),
            new PathSegment(PolarisEntityType.TABLE_LIKE, "table-1"));

    OpaPolarisAuthorizer authorizer =
        new OpaPolarisAuthorizer(
            URI.create("http://opa.example.com:8181/v1/data/polaris/allow"),
            mock(CloseableHttpClient.class),
            JsonMapper.builder().build(),
            null,
            null,
            "test-realm") {
          @Override
          <T> T httpClientExecute(
              ClassicHttpRequest request, HttpClientResponseHandler<? extends T> responseHandler)
              throws HttpException, IOException {
            requestCount[0]++;
            return responseHandler.handleResponse(mockResponse);
          }
        };

    AuthorizationDecision decision =
        authorizer.authorize(
            authzState,
            new AuthorizationRequest(
                principal,
                List.of(
                    new SingleTargetAuthorizationIntent(
                        PolarisAuthorizableOperation.REMOVE_TABLE_PROPERTIES, tableTarget),
                    new SingleTargetAuthorizationIntent(
                        PolarisAuthorizableOperation.SET_TABLE_SNAPSHOT_REF, tableTarget))));

    assertThat(decision.isAllowed()).isTrue();
    assertThat(requestCount[0]).isEqualTo(2);
  }

  @Test
  void serializesInputWithRealm() throws Exception {
    final String[] capturedRequestBody = new String[1];

    HttpServer server = createServerWithRequestCapture(capturedRequestBody);
    try {
      URI policyUri =
          URI.create(
              "http://localhost:" + server.getAddress().getPort() + "/v1/data/polaris/allow");
      OpaPolarisAuthorizer authorizer =
          new OpaPolarisAuthorizer(
              policyUri,
              HttpClients.createDefault(),
              JsonMapper.builder().build(),
              null,
              null,
              "explicit-realm");

      PolarisPrincipal principal =
          PolarisPrincipal.of("eve", AttributeMap.EMPTY, Set.of("auditor"));

      assertThatNoException()
          .isThrownBy(
              () ->
                  authorizer
                      .authorize(
                          new AuthorizationState(mock(PolarisResolutionManifest.class)),
                          new AuthorizationRequest(
                              principal,
                              authorizationIntents(
                                  PolarisAuthorizableOperation.GET_CATALOG, null, null)))
                      .throwIfDenied());

      ObjectMapper mapper = JsonMapper.builder().build();
      JsonNode root = mapper.readTree(capturedRequestBody[0]);
      var context = root.path("input").path("context");
      assertThat(context.has("request_id")).isTrue();
      assertThat(context.path("realm").asText()).isEqualTo("explicit-realm");
    } finally {
      server.stop(0);
    }
  }

  @Test
  void serializesRealmInAuthorizePath() throws Exception {
    final String[] capturedRequestBody = new String[1];

    HttpServer server = createServerWithRequestCapture(capturedRequestBody);
    try {
      URI policyUri =
          URI.create(
              "http://localhost:" + server.getAddress().getPort() + "/v1/data/polaris/allow");
      OpaPolarisAuthorizer authorizer =
          new OpaPolarisAuthorizer(
              policyUri,
              HttpClients.createDefault(),
              JsonMapper.builder().build(),
              null,
              null,
              "tenant-xyz");

      PolarisResolutionManifest resolutionManifest = mock(PolarisResolutionManifest.class);
      AuthorizationState authzState = new AuthorizationState(resolutionManifest);

      PolarisPrincipal principal =
          PolarisPrincipal.of("alice", AttributeMap.EMPTY, Set.of("admin"));
      AuthorizationRequest request = requestWithCatalogTarget(principal);

      assertThatNoException().isThrownBy(() -> authorizer.authorize(authzState, request));

      ObjectMapper mapper = JsonMapper.builder().build();
      JsonNode root = mapper.readTree(capturedRequestBody[0]);
      assertThat(root.path("input").path("context").get("realm").asText()).isEqualTo("tenant-xyz");
    } finally {
      server.stop(0);
    }
  }

  @Test
  void requestIdIsIncludedInContextWhenProvided() throws Exception {
    final String[] capturedRequestBody = new String[1];

    HttpServer server = createServerWithRequestCapture(capturedRequestBody);
    try {
      URI policyUri =
          URI.create(
              "http://localhost:" + server.getAddress().getPort() + "/v1/data/polaris/allow");
      OpaPolarisAuthorizer authorizer =
          new OpaPolarisAuthorizer(
              policyUri,
              HttpClients.createDefault(),
              JsonMapper.builder().build(),
              null,
              "test-id",
              "test-realm");

      PolarisPrincipal principal =
          PolarisPrincipal.of(
              "eve",
              ImmutableAttributeMap.builder()
                  .put(new AttributeKey<>("department"), "finance")
                  .build(),
              Set.of("auditor"));
      PolarisResolvedPathWrapper target = new PolarisResolvedPathWrapper(List.of());
      PolarisResolvedPathWrapper secondary = new PolarisResolvedPathWrapper(List.of());

      assertThatNoException()
          .isThrownBy(
              () ->
                  authorizer
                      .authorize(
                          new AuthorizationState(mock(PolarisResolutionManifest.class)),
                          new AuthorizationRequest(
                              principal,
                              authorizationIntents(
                                  PolarisAuthorizableOperation.LOAD_VIEW,
                                  List.of(target),
                                  List.of(secondary))))
                      .throwIfDenied());

      ObjectMapper mapper = JsonMapper.builder().build();
      JsonNode root = mapper.readTree(capturedRequestBody[0]);
      assertThat(root.at("/input/context/request_id").asText()).isEqualTo("test-id");
    } finally {
      server.stop(0);
    }
  }

  @Test
  void requestIdFallsBackToRandomUuidWhenNull() throws Exception {
    final String[] capturedRequestBody = new String[1];

    HttpServer server = createServerWithRequestCapture(capturedRequestBody);
    try {
      URI policyUri =
          URI.create(
              "http://localhost:" + server.getAddress().getPort() + "/v1/data/polaris/allow");
      OpaPolarisAuthorizer authorizer =
          new OpaPolarisAuthorizer(
              policyUri,
              HttpClients.createDefault(),
              JsonMapper.builder().build(),
              null,
              null,
              "test-realm");

      PolarisPrincipal principal =
          PolarisPrincipal.of(
              "eve",
              ImmutableAttributeMap.builder()
                  .put(new AttributeKey<>("department"), "finance")
                  .build(),
              Set.of("auditor"));
      PolarisResolvedPathWrapper target = new PolarisResolvedPathWrapper(List.of());
      PolarisResolvedPathWrapper secondary = new PolarisResolvedPathWrapper(List.of());

      assertThatNoException()
          .isThrownBy(
              () ->
                  authorizer
                      .authorize(
                          new AuthorizationState(mock(PolarisResolutionManifest.class)),
                          new AuthorizationRequest(
                              principal,
                              authorizationIntents(
                                  PolarisAuthorizableOperation.LOAD_VIEW,
                                  List.of(target),
                                  List.of(secondary))))
                      .throwIfDenied());

      ObjectMapper mapper = JsonMapper.builder().build();
      JsonNode root = mapper.readTree(capturedRequestBody[0]);
      String requestId = root.at("/input/context/request_id").asText();
      assertThatNoException().isThrownBy(() -> UUID.fromString(requestId));
    } finally {
      server.stop(0);
    }
  }

  private AuthorizationRequest requestWithCatalogTarget(PolarisPrincipal principal) {
    return new AuthorizationRequest(
        principal,
        List.of(
            new SingleTargetAuthorizationIntent(
                PolarisAuthorizableOperation.GET_CATALOG,
                PolarisSecurable.of(new PathSegment(PolarisEntityType.CATALOG, "catalog-1")))));
  }

  private List<AuthorizationIntent> authorizationIntents(
      PolarisAuthorizableOperation operation,
      List<PolarisResolvedPathWrapper> targets,
      List<PolarisResolvedPathWrapper> secondaries) {
    List<PolarisSecurable> targetSecurables = toSecurables(targets);
    List<PolarisSecurable> secondarySecurables = toSecurables(secondaries);
    if (targetSecurables.isEmpty()) {
      return List.of(new TargetlessAuthorizationIntent(operation));
    }
    if (targetSecurables.size() == 1 && secondarySecurables.size() == 1) {
      return List.of(
          new RenameAuthorizationIntent(
              operation, targetSecurables.getFirst(), secondarySecurables.getFirst()));
    }
    return targetSecurables.stream()
        .<AuthorizationIntent>map(target -> new SingleTargetAuthorizationIntent(operation, target))
        .toList();
  }

  private List<PolarisSecurable> toSecurables(List<PolarisResolvedPathWrapper> paths) {
    if (paths == null) {
      return List.of();
    }
    List<PolarisSecurable> securables = new ArrayList<>();
    for (PolarisResolvedPathWrapper path : paths) {
      if (path != null
          && path.getResolvedLeafEntity() != null
          && path.getResolvedLeafEntity().getEntity().getType() != PolarisEntityType.ROOT) {
        securables.add(toSecurable(path));
      }
    }
    return securables;
  }

  private PolarisSecurable toSecurable(PolarisResolvedPathWrapper path) {
    List<PathSegment> segments = new ArrayList<>();
    if (path.getResolvedParentPath() != null) {
      for (ResolvedPolarisEntity parent : path.getResolvedParentPath()) {
        if (parent.getEntity().getType() != PolarisEntityType.ROOT) {
          segments.add(new PathSegment(parent.getEntity().getType(), parent.getEntity().getName()));
        }
      }
    }
    ResolvedPolarisEntity leaf = path.getResolvedLeafEntity();
    segments.add(new PathSegment(leaf.getEntity().getType(), leaf.getEntity().getName()));
    return PolarisSecurable.of(
        segments.getFirst(), segments.stream().skip(1).toArray(PathSegment[]::new));
  }

  private ResolvedPolarisEntity createResolvedEntity(PolarisEntity entity) {
    return new ResolvedPolarisEntity(entity, List.of(), List.of());
  }

  /**
   * Helper method to create and start an HTTP server that captures request bodies.
   *
   * @param capturedRequestBody Array to store the captured request body
   * @return Started HttpServer instance
   */
  private HttpServer createServerWithRequestCapture(String[] capturedRequestBody)
      throws IOException {
    HttpServer server = HttpServer.create(new InetSocketAddress(0), 0);
    server.createContext(
        "/v1/data/polaris/allow",
        new HttpHandler() {
          @Override
          public void handle(HttpExchange exchange) throws IOException {
            // Capture request body
            byte[] requestBytes = exchange.getRequestBody().readAllBytes();
            capturedRequestBody[0] = new String(requestBytes, StandardCharsets.UTF_8);

            String response = "{\"result\":{\"allow\":true}}";
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, response.length());
            try (OutputStream os = exchange.getResponseBody()) {
              os.write(response.getBytes(StandardCharsets.UTF_8));
            }
          }
        });
    server.start();
    return server;
  }

  /**
   * Helper method to create and start an HTTP server that returns a simple allow response.
   *
   * @return Started HttpServer instance
   */
  private HttpServer createServerWithAllowResponse() throws IOException {
    HttpServer server = HttpServer.create(new InetSocketAddress(0), 0);
    server.createContext(
        "/v1/data/polaris/allow",
        new HttpHandler() {
          @Override
          public void handle(HttpExchange exchange) throws IOException {
            String response = "{\"result\":{\"allow\":true}}";
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, response.length());
            try (OutputStream os = exchange.getResponseBody()) {
              os.write(response.getBytes(StandardCharsets.UTF_8));
            }
          }
        });
    server.start();
    return server;
  }

  /**
   * Helper method to capture and verify HTTP request Authorization header.
   *
   * @param capturedRequest The request issued to the HTTP client to verify against
   * @param expectedToken The expected bearer token value, or null if no Authorization header
   *     expected
   */
  private void verifyAuthorizationHeader(ClassicHttpRequest capturedRequest, String expectedToken) {
    // Capture the HTTP request to verify the bearer token header
    assertThat(capturedRequest).isInstanceOf(HttpPost.class);

    if (expectedToken != null) {
      // Verify the Authorization header is present and contains the expected token
      assertThat(capturedRequest.containsHeader("Authorization"))
          .as("Authorization header should be present when bearer token is provided")
          .isTrue();
      String authHeader = capturedRequest.getFirstHeader("Authorization").getValue();
      assertThat(authHeader)
          .as("Authorization header should contain the correct bearer token")
          .isEqualTo("Bearer " + expectedToken);
    } else {
      // Verify no Authorization header is present when token is null
      assertThat(capturedRequest.containsHeader("Authorization"))
          .as("Authorization header should not be present when token provider returns null")
          .isFalse();
    }
  }
}
