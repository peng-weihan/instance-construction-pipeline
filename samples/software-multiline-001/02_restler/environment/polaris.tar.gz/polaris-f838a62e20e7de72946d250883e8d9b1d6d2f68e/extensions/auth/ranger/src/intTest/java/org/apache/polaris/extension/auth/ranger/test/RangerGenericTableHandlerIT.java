/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.extension.auth.ranger.test;

import static io.restassured.RestAssured.given;

import io.restassured.http.ContentType;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

public class RangerGenericTableHandlerIT extends RangerIntegrationTestBase {

  private String catalogName;
  private String namespace;
  private String baseLocation;
  private String rootToken;

  @BeforeEach
  void setupBaseCatalog(@TempDir Path tempDir) throws Exception {
    rootToken = getRootToken();
    catalogName = "ranger-gt-" + UUID.randomUUID().toString().replace("-", "");
    namespace = "ns_" + UUID.randomUUID().toString().replace("-", "");
    Path warehouse = tempDir.resolve("warehouse");
    Files.createDirectory(warehouse);
    baseLocation = warehouse.toUri().toString();
    createFileCatalog(rootToken, catalogName, baseLocation, List.of(baseLocation));
    createNamespace(rootToken, catalogName, namespace);
  }

  @Test
  void genericTableCreateAndDropAuthorization() throws Exception {
    String rootToken = this.rootToken;
    String strangerToken = createPrincipalAndGetToken("stranger-" + UUID.randomUUID());
    String tableName = "gt_" + UUID.randomUUID().toString().replace("-", "");

    Map<String, Object> tablePayload =
        Map.of("name", tableName, "format", "ICEBERG", "doc", "doc", "properties", Map.of());

    // Stranger cannot list generic tables
    given()
        .header("Authorization", "Bearer " + strangerToken)
        .get("/api/catalog/polaris/v1/{cat}/namespaces/{ns}/generic-tables", catalogName, namespace)
        .then()
        .statusCode(403);

    // Root lists generic tables (initially empty)
    given()
        .header("Authorization", "Bearer " + rootToken)
        .get("/api/catalog/polaris/v1/{cat}/namespaces/{ns}/generic-tables", catalogName, namespace)
        .then()
        .statusCode(200);

    // Stranger cannot create generic table
    given()
        .contentType(ContentType.JSON)
        .header("Authorization", "Bearer " + strangerToken)
        .body(toJson(tablePayload))
        .post(
            "/api/catalog/polaris/v1/{cat}/namespaces/{ns}/generic-tables", catalogName, namespace)
        .then()
        .statusCode(403);

    // Root creates generic table
    given()
        .contentType(ContentType.JSON)
        .header("Authorization", "Bearer " + rootToken)
        .body(toJson(tablePayload))
        .post(
            "/api/catalog/polaris/v1/{cat}/namespaces/{ns}/generic-tables", catalogName, namespace)
        .then()
        .statusCode(200);

    // Root drops generic table
    given()
        .header("Authorization", "Bearer " + rootToken)
        .delete(
            "/api/catalog/polaris/v1/{cat}/namespaces/{ns}/generic-tables/{table}",
            catalogName,
            namespace,
            tableName)
        .then()
        .statusCode(204);
  }
}
