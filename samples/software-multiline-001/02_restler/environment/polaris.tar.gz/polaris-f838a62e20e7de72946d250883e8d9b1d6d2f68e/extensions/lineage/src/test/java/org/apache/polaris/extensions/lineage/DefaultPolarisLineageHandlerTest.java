/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.extensions.lineage;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class DefaultPolarisLineageHandlerTest {
  @Mock private LineageConfiguration configuration;

  private DefaultPolarisLineageHandler handler;

  @BeforeEach
  void setUp() {
    handler = new DefaultPolarisLineageHandler(configuration);
  }

  @Test
  void throwsWhenStaticConfigDisabled() {
    when(configuration.enabled()).thenReturn(false);

    assertThatThrownBy(() -> handler.query(queryRequest()))
        .isInstanceOf(UnsupportedOperationException.class)
        .hasMessageContaining("polaris.lineage.enabled");
  }

  @Test
  void throwsNotImplementedWhenLineageEnabled() {
    when(configuration.enabled()).thenReturn(true);

    assertThatThrownBy(() -> handler.query(queryRequest()))
        .isInstanceOf(UnsupportedOperationException.class)
        .hasMessageContaining("Lineage query is not implemented yet");
  }

  private static LineageQueryRequest queryRequest() {
    return new LineageQueryRequest(
        "dataset:test:orders", LineageDirection.BOTH, LineageGranularity.DATASET);
  }
}
