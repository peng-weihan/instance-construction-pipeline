/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.extensions.lineage;

import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;

/** Internal dataset metadata used in a lineage query response. */
record LineageData(
    OptionalLong catalogId,
    long datasetId,
    String namespace,
    String name,
    Optional<String> entitySubType,
    long createdAt,
    long updatedAt) {
  LineageData {
    Objects.requireNonNull(catalogId, "catalogId must be non-null");
    Objects.requireNonNull(namespace, "namespace must be non-null");
    Objects.requireNonNull(name, "name must be non-null");
    Objects.requireNonNull(entitySubType, "entitySubType must be non-null");
  }

  LineageData(
      long catalogId,
      long datasetId,
      String namespace,
      String name,
      String entitySubType,
      long createdAt,
      long updatedAt) {
    this(
        OptionalLong.of(catalogId),
        datasetId,
        namespace,
        name,
        Optional.of(entitySubType),
        createdAt,
        updatedAt);
  }
}
