/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.extensions.lineage;

import java.util.List;
import java.util.Objects;

/** An internal node used in a lineage query response. */
record LineageNode(
    String id,
    LineageNodeType type,
    LineageData data,
    boolean opaque,
    List<LineageFieldMapping> fieldMappings) {
  LineageNode {
    Objects.requireNonNull(id, "id must be non-null");
    Objects.requireNonNull(type, "type must be non-null");
    fieldMappings =
        List.copyOf(Objects.requireNonNull(fieldMappings, "fieldMappings must be non-null"));
  }

  LineageNode(String id, LineageNodeType type, LineageData data, boolean opaque) {
    this(id, type, data, opaque, List.of());
  }
}
