/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import org.openapitools.generator.gradle.plugin.tasks.GenerateTask

plugins {
  alias(libs.plugins.openapi.generator)
  id("polaris-server")
  id("org.kordamp.gradle.jandex")
}

val semanticModelModels =
  listOf(
      "SemanticModelDocument",
      "SemanticModelIdentifier",
      "CreateSemanticModelRequest",
      "UpdateSemanticModelRequest",
      "LoadSemanticModelResponse",
      "ListSemanticModelsResponse",
    )
    .joinToString(",")

dependencies {
  implementation(project(":polaris-core"))
  // CatalogAdapter and other shared catalog service abstractions.
  implementation(project(":polaris-runtime-service"))

  // Dependencies required by the generated Ossie semantic-model REST API code (mirrors the set
  // used by the polaris-api-catalog-service generated code).
  implementation(platform(libs.iceberg.bom))
  implementation("org.apache.iceberg:iceberg-api")
  implementation("org.apache.iceberg:iceberg-core")

  implementation(libs.jakarta.annotation.api)
  implementation(libs.jakarta.inject.api)
  implementation(libs.jakarta.validation.api)
  implementation(libs.swagger.annotations)
  implementation(libs.guava)

  implementation(libs.jakarta.servlet.api)
  implementation(libs.jakarta.ws.rs.api)

  implementation(platform(libs.micrometer.bom))
  implementation("io.micrometer:micrometer-core")

  implementation(platform(libs.jackson.bom))
  implementation("com.fasterxml.jackson.core:jackson-annotations")
  implementation("com.fasterxml.jackson.core:jackson-core")
  implementation("com.fasterxml.jackson.core:jackson-databind")

  compileOnly(libs.microprofile.fault.tolerance.api)
  compileOnly(libs.jakarta.enterprise.cdi.api)

  compileOnly(project(":polaris-immutables"))
  annotationProcessor(project(":polaris-immutables", configuration = "processor"))

  testImplementation(platform(libs.junit.bom))
  testImplementation("org.junit.jupiter:junit-jupiter")
  testImplementation(libs.assertj.core)

  // Real-manifest handler tests bootstrap services via the runtime-service test fixtures
  // (TestServices), which is the only way to reproduce the strict resolution-manifest behavior
  // that the pure-Mockito unit test cannot.
  testImplementation(testFixtures(project(":polaris-runtime-service")))
  testImplementation(project(":polaris-api-management-model"))
  testImplementation(project(":polaris-api-management-service"))
  testImplementation(project(":polaris-api-iceberg-service"))
  testImplementation(project(":polaris-api-catalog-service"))
  testCompileOnly(project(":polaris-immutables"))
  testAnnotationProcessor(project(":polaris-immutables", configuration = "processor"))
}

val rootDir = rootProject.layout.projectDirectory
val specsDir = rootDir.dir("spec")
val templatesDir = rootDir.dir("server-templates")
// Use a different directory than 'generated/', because OpenAPI generator's `GenerateTask` adds the
// whole directory to its task output, but 'generated/' is not exclusive to that task and in turn
// breaks Gradle's caching.
val generatedDir = project.layout.buildDirectory.dir("generated-openapi")
val generatedOpenApiSrcDir = project.layout.buildDirectory.dir("generated-openapi/src/main/java")

openApiGenerate {
  // The OpenAPI generator does NOT resolve relative paths correctly against the Gradle project
  // directory
  inputSpec = provider { specsDir.file("polaris-catalog-service.yaml").asFile.absolutePath }
  generatorName = "jaxrs-resteasy"
  outputDir = provider { generatedDir.get().asFile.absolutePath }
  // Distinct packages so the generated code does not split-package with
  // polaris-api-catalog-service.
  apiPackage = "org.apache.polaris.service.catalog.semanticmodel.api"
  modelPackage = "org.apache.polaris.service.catalog.semanticmodel.types"
  ignoreFileOverride.set(provider { rootDir.file(".openapi-generator-ignore").asFile.absolutePath })
  removeOperationIdPrefix.set(true)
  templateDir.set(provider { templatesDir.asFile.absolutePath })
  globalProperties.put("apis", "SemanticModelApi")
  globalProperties.put("models", semanticModelModels)
  globalProperties.put("apiDocs", "false")
  globalProperties.put("modelTests", "false")
  configOptions.put("resourceName", "catalog")
  configOptions.put("useTags", "true")
  configOptions.put("useBeanValidation", "true")
  configOptions.put("sourceFolder", "src/main/java")
  configOptions.put("useJakartaEe", "true")
  configOptions.put("generateBuilders", "true")
  configOptions.put("generateConstructorWithAllArgs", "true")
  configOptions.put("hideGenerationTimestamp", "true")
  configOptions.put("openApiNullable", "false")
  additionalProperties.put("apiNamePrefix", "PolarisCatalog")
  additionalProperties.put("apiNameSuffix", "")
  additionalProperties.put("metricsPrefix", "polaris")
  serverVariables.put("basePath", "api/catalog")
  importMappings =
    mapOf(
      "ErrorModel" to "org.apache.iceberg.rest.responses.ErrorResponse",
      "IcebergErrorResponse" to "org.apache.iceberg.rest.responses.ErrorResponse",
    )
}

listOf("sourcesJar", "compileJava", "processResources").forEach { task ->
  tasks.named(task) { dependsOn("openApiGenerate") }
}

sourceSets { main { java { srcDir(generatedOpenApiSrcDir) } } }

tasks.named<GenerateTask>("openApiGenerate") {
  inputs.dir(templatesDir)
  inputs.dir(specsDir)
  cleanupOutput = true
}
