/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.service.lineage;

/**
 * Replacement point for OpenLineage ingest behavior.
 *
 * <p>Downstream deployments that have their own OpenLineage persistence path, forwarding backend,
 * or custom routing logic implement this interface and register it as a CDI bean. The default
 * implementation is a no-op that accepts and discards every event.
 *
 * <p>Implementations must not return JAX-RS types or accept {@code SecurityContext} — HTTP mapping
 * is the adapter's responsibility. Each ingest call is inherently realm-scoped; an implementation
 * that needs realm-specific context can be {@code @RequestScoped} and inject {@code
 * RealmContext}/{@code CallContext} directly.
 */
public interface OpenLineageIngestProvider {

  OpenLineageIngestResult ingest(OpenLineageIngestRequest request);
}
