/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.persistence.nosql.nodeids.impl;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.polaris.ids.api.IdGenerator;
import org.apache.polaris.persistence.nosql.nodeids.spi.NodeManagementState;
import org.apache.polaris.persistence.nosql.nodeids.spi.NodeStore;
import org.apache.polaris.persistence.nosql.nodeids.spi.NodeStoreFactory;
import org.jspecify.annotations.NonNull;

public class MockNodeStoreFactory implements NodeStoreFactory {
  private final AtomicReference<NodeManagementState> nodeState = new AtomicReference<>();
  private final NodeStore nodeStore;

  public MockNodeStoreFactory() {
    this(new MockNodeStore());
  }

  public MockNodeStoreFactory(NodeStore nodeStore) {
    this.nodeStore = nodeStore;
  }

  @Override
  public boolean storeManagementState(@NonNull NodeManagementState state) {
    return nodeState.compareAndSet(null, state);
  }

  @Override
  public Optional<NodeManagementState> fetchManagementState() {
    return Optional.ofNullable(nodeState.get());
  }

  @NonNull
  @Override
  public NodeStore createNodeStore(@NonNull IdGenerator idGenerator) {
    return nodeStore;
  }
}
