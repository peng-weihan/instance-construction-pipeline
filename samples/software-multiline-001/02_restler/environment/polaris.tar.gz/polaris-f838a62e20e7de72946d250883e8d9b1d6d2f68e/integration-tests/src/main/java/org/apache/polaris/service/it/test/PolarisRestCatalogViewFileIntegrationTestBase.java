/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.service.it.test;

import java.lang.reflect.Field;
import java.nio.file.Path;
import org.apache.iceberg.view.ViewCatalogTests;
import org.apache.polaris.core.admin.model.FileStorageConfigInfo;
import org.apache.polaris.core.admin.model.StorageConfigInfo;

/** Runs PolarisRestCatalogViewIntegrationTest on the local filesystem. */
public abstract class PolarisRestCatalogViewFileIntegrationTestBase
    extends PolarisRestCatalogViewIntegrationBase {

  @Override
  protected StorageConfigInfo getStorageConfigInfo() {
    Path tempDir;
    try {
      Field field = ViewCatalogTests.class.getDeclaredField("tempDir");
      field.setAccessible(true);
      tempDir = (Path) field.get(this);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
    String baseLocation = tempDir.toAbsolutePath().toUri().toString();
    if (baseLocation.endsWith("/")) {
      baseLocation = baseLocation.substring(0, baseLocation.length() - 1);
    }
    return FileStorageConfigInfo.builder()
        .setStorageType(StorageConfigInfo.StorageTypeEnum.FILE)
        .setAllowedLocations(allowedLocations(baseLocation))
        .build();
  }

  @Override
  protected boolean shouldSkip() {
    return false;
  }
}
