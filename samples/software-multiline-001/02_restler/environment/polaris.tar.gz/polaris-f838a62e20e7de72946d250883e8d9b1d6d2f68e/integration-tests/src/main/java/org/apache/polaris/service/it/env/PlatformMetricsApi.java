/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.service.it.env;

import static org.assertj.core.api.Assertions.assertThat;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.core.Response;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.stream.Collectors;
import org.hawkular.agent.prometheus.text.TextPrometheusMetricsProcessor;
import org.hawkular.agent.prometheus.types.MetricFamily;
import org.hawkular.agent.prometheus.walkers.CollectorPrometheusMetricsWalker;

public class PlatformMetricsApi extends RestApi {

  PlatformMetricsApi(Client client, URI metricsApiEndpoint) {
    super(client, metricsApiEndpoint, "text/plain");
  }

  /** Fetches all Prometheus metric families from {@code q/metrics}. */
  public Map<String, MetricFamily> fetchMetrics() {
    try (Response response = request().get()) {
      assertThat(response).returns(Response.Status.OK.getStatusCode(), Response::getStatus);
      String body = response.readEntity(String.class);
      InputStream inputStream = new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8));
      CollectorPrometheusMetricsWalker walker = new CollectorPrometheusMetricsWalker();
      new TextPrometheusMetricsProcessor(inputStream, walker).walk();
      return walker.getAllMetricFamilies().stream()
          .collect(
              Collectors.toMap(
                  MetricFamily::getName,
                  metricFamily -> metricFamily,
                  (mf1, mf2) -> {
                    throw new IllegalStateException("Duplicate metric family: " + mf1.getName());
                  }));
    }
  }
}
