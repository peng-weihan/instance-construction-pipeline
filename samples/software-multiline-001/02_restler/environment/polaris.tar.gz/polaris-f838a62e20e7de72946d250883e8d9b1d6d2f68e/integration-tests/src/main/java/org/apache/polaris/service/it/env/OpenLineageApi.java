/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.service.it.env;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.Response;
import java.net.URI;

/** Test helper for the OpenLineage ingest endpoints under {@code /api/openlineage/v1}. */
public class OpenLineageApi extends PolarisRestApi {

  OpenLineageApi(Client client, PolarisApiEndpoints endpoints, String authToken, URI uri) {
    super(client, endpoints, authToken, uri);
  }

  /**
   * POSTs a JSON event body to the single-event ingest endpoint ({@code POST
   * /api/openlineage/v1/lineage}) and returns the raw response. The caller is responsible for
   * closing the response.
   */
  public Response sendEvent(String json) {
    return request("lineage").post(Entity.json(json));
  }

  /**
   * POSTs a JSON array body to the batch ingest endpoint ({@code POST
   * /api/openlineage/v1/lineage/batch}) and returns the raw response. The caller is responsible for
   * closing the response.
   */
  public Response sendBatch(String json) {
    return request("lineage/batch").post(Entity.json(json));
  }
}
