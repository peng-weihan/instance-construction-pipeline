/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.polaris.service.it.env;

import java.net.URI;
import java.util.Map;
import java.util.Optional;

/**
 * This is a holder for access information to a particular Polaris Server. Test cases may use only
 * the provided admin credentials or create new principals.
 */
public interface Server extends AutoCloseable {

  String DEFAULT_REALM_HEADER = "Polaris-Realm";
  String DEFAULT_REALM_ID = "POLARIS";

  default String realmId() {
    return DEFAULT_REALM_ID;
  }

  default String realmHeaderName() {
    return DEFAULT_REALM_HEADER;
  }

  default Map<String, String> headers() {
    return Map.of(realmHeaderName(), realmId());
  }

  /**
   * The base URI to all Polaris APIs (e.g. the common base of the Iceberg REST API endpoints and
   * Polaris Management API endpoints).
   *
   * @see PolarisApiEndpoints
   */
  URI baseUri();

  /**
   * The base URI for the platform management interface (exposing metrics and health checks). Not to
   * be confused with the Polaris Management API. This URI includes the management interface root
   * path, usually {@code /q} on Quarkus platforms.
   *
   * <p>The management URI may be unavailable; in such cases this method returns empty.
   */
  default Optional<URI> managementUri() {
    return Optional.empty();
  }

  ClientPrincipal adminCredentials();
}
