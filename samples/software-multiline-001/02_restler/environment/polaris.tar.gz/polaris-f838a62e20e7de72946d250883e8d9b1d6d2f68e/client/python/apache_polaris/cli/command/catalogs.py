#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

from apache_polaris.cli.command import Command
from apache_polaris.cli.exceptions import CliError
from apache_polaris.cli.constants import (
    StorageType,
    CatalogType,
    CatalogConnectionType,
    Subcommands,
    Arguments,
    AuthenticationType,
    ServiceIdentityType,
    UNIT_SEPARATOR,
)
from apache_polaris.cli.options.option_tree import Argument

import logging
from dataclasses import dataclass, field
from pydantic import StrictStr, SecretStr
from typing import Dict, List, Optional, Union, Tuple, Callable, cast

from apache_polaris.sdk.management import (
    PolarisDefaultApi,
    CreateCatalogRequest,
    UpdateCatalogRequest,
    StorageConfigInfo,
    ExternalCatalog,
    AwsStorageConfigInfo,
    AzureStorageConfigInfo,
    GcpStorageConfigInfo,
    PolarisCatalog,
    CatalogProperties,
    BearerAuthenticationParameters,
    GcpAuthenticationParameters,
    ImplicitAuthenticationParameters,
    OAuthClientCredentialsParameters,
    SigV4AuthenticationParameters,
    HadoopConnectionConfigInfo,
    HiveConnectionConfigInfo,
    IcebergRestConnectionConfigInfo,
    AwsIamServiceIdentityInfo,
)
from apache_polaris.cli.command.utils import (
    get_catalog_api_client,
    format_timestamp,
    paginate,
)
from apache_polaris.sdk.catalog import IcebergCatalogAPI
from apache_polaris.sdk.catalog.api.policy_api import PolicyAPI

logger = logging.getLogger(__name__)


@dataclass
class CatalogsCommand(Command):
    """
    A Command implementation to represent `polaris catalogs`. The instance attributes correspond to parameters
    that can be provided to various subcommands, except `catalogs_subcommand` which represents the subcommand
    itself.

    Example commands:
        * polaris catalogs create cat_name --storage-type s3 --default-base-location s3://bucket/path --role-arn ...
        * polaris catalogs update cat_name --default-base-location s3://new-bucket/new-location
        * polaris catalogs list
    """

    catalogs_subcommand: str
    catalog_type: Optional[str] = None
    default_base_location: Optional[str] = None
    storage_type: Optional[str] = None
    storage_name: Optional[str] = None
    allowed_locations: Optional[List[str]] = None
    role_arn: Optional[str] = None
    external_id: Optional[str] = None
    user_arn: Optional[str] = None
    region: Optional[str] = None
    tenant_id: Optional[str] = None
    multi_tenant_app_name: Optional[str] = None
    hierarchical: Optional[bool] = None
    consent_url: Optional[str] = None
    service_account: Optional[str] = None
    catalog_name: Optional[str] = None
    properties: Optional[Dict[str, StrictStr]] = field(default_factory=dict)
    set_properties: Optional[Dict[str, StrictStr]] = field(default_factory=dict)
    remove_properties: Optional[List[str]] = None
    hadoop_warehouse: Optional[str] = None
    hive_warehouse: Optional[str] = None
    iceberg_remote_catalog_name: Optional[str] = None
    endpoint: Optional[str] = None
    endpoint_internal: Optional[str] = None
    sts_endpoint: Optional[str] = None
    sts_unavailable: Optional[bool] = None
    kms_unavailable: Optional[bool] = None
    path_style_access: Optional[bool] = None
    current_kms_key: Optional[str] = None
    allowed_kms_keys: Optional[List[str]] = None
    encryption_keys: Optional[List[str]] = None
    decryption_keys: Optional[List[str]] = None
    catalog_connection_type: Optional[str] = None
    catalog_authentication_type: Optional[str] = None
    catalog_service_identity_type: Optional[str] = None
    catalog_service_identity_iam_arn: Optional[str] = None
    catalog_uri: Optional[str] = None
    catalog_token_uri: Optional[str] = None
    catalog_client_id: Optional[str] = None
    catalog_client_secret: Optional[str] = None
    catalog_client_scopes: Optional[List[str]] = None
    catalog_bearer_token: Optional[str] = None
    catalog_role_arn: Optional[str] = None
    catalog_role_session_name: Optional[str] = None
    catalog_external_id: Optional[str] = None
    catalog_signing_region: Optional[str] = None
    catalog_signing_name: Optional[str] = None
    page_size: Optional[int] = None

    def __post_init__(self) -> None:
        if self.properties is None:
            self.properties = {}
        if self.set_properties is None:
            self.set_properties = {}
        if self.hierarchical is None:
            self.hierarchical = False
        if self.sts_unavailable is None:
            self.sts_unavailable = False
        if self.kms_unavailable is None:
            self.kms_unavailable = False
        if self.path_style_access is None:
            self.path_style_access = False

    def validate(self) -> None:
        if self.current_kms_key:
            logger.warning(
                "%s is deprecated; use %s instead.",
                Argument.to_flag_name(Arguments.KMS_KEY_CURRENT),
                Argument.to_flag_name(Arguments.KMS_KEY_ENCRYPTION),
            )
        if self.allowed_kms_keys:
            logger.warning(
                "%s is deprecated; use %s instead.",
                Argument.to_flag_name(Arguments.KMS_KEY_ALLOWED),
                Argument.to_flag_name(Arguments.KMS_KEY_ENCRYPTION),
            )

        if self.catalogs_subcommand in {
            Subcommands.CREATE,
            Subcommands.DELETE,
            Subcommands.GET,
            Subcommands.UPDATE,
            Subcommands.SUMMARIZE,
        }:
            if not self.catalog_name:
                raise CliError(
                    f"Missing required argument: {Argument.to_flag_name(Arguments.CATALOG)}"
                )

        if self.catalogs_subcommand == Subcommands.CREATE:
            if not self.storage_type:
                raise CliError(
                    f"Missing required argument:"
                    f" {Argument.to_flag_name(Arguments.STORAGE_TYPE)}"
                )
            if not self.default_base_location:
                raise CliError(
                    f"Missing required argument:"
                    f" {Argument.to_flag_name(Arguments.DEFAULT_BASE_LOCATION)}"
                )
            if self.catalog_type == CatalogType.EXTERNAL.value:
                if self.catalog_authentication_type == AuthenticationType.OAUTH.value:
                    if (
                        not self.catalog_token_uri
                        or not self.catalog_client_id
                        or not self.catalog_client_secret
                        or not self.catalog_client_scopes
                        or len(self.catalog_client_scopes) == 0
                    ):
                        raise CliError(
                            f"Authentication type 'OAUTH' requires"
                            f" {Argument.to_flag_name(Arguments.CATALOG_TOKEN_URI)},"
                            f" {Argument.to_flag_name(Arguments.CATALOG_CLIENT_ID)},"
                            f" {Argument.to_flag_name(Arguments.CATALOG_CLIENT_SECRET)},"
                            f" and at least one {Argument.to_flag_name(Arguments.CATALOG_CLIENT_SCOPE)}."
                        )
                elif (
                    self.catalog_authentication_type == AuthenticationType.BEARER.value
                ):
                    if not self.catalog_bearer_token:
                        raise CliError(
                            f"Missing required argument for authentication type 'BEARER':"
                            f" {Argument.to_flag_name(Arguments.CATALOG_BEARER_TOKEN)}"
                        )
                elif self.catalog_authentication_type == AuthenticationType.SIGV4.value:
                    if not self.catalog_role_arn or not self.catalog_signing_region:
                        raise CliError(
                            f"Authentication type 'SIGV4' requires"
                            f" {Argument.to_flag_name(Arguments.CATALOG_ROLE_ARN)}"
                            f" and {Argument.to_flag_name(Arguments.CATALOG_SIGNING_REGION)}"
                        )
                if self.catalog_connection_type == CatalogConnectionType.HADOOP.value:
                    if not self.hadoop_warehouse or not self.catalog_uri:
                        raise CliError(
                            f"Missing required argument for connection type 'hadoop':"
                            f" {Argument.to_flag_name(Arguments.HADOOP_WAREHOUSE)}"
                            f" and {Argument.to_flag_name(Arguments.CATALOG_URI)}"
                        )
                elif self.catalog_connection_type == CatalogConnectionType.HIVE.value:
                    if not self.hive_warehouse or not self.catalog_uri:
                        raise CliError(
                            f"Missing required argument for connection type 'hive':"
                            f" {Argument.to_flag_name(Arguments.HIVE_WAREHOUSE)}"
                            f" and {Argument.to_flag_name(Arguments.CATALOG_URI)}"
                        )
        if self.catalog_service_identity_type == ServiceIdentityType.AWS_IAM.value:
            if not self.catalog_service_identity_iam_arn:
                raise CliError(
                    f"Missing required argument for service identity type 'AWS_IAM':"
                    f" {Argument.to_flag_name(Arguments.CATALOG_SERVICE_IDENTITY_IAM_ARN)}"
                )

        if self.storage_type == StorageType.S3.value:
            if self._has_azure_storage_info() or self._has_gcs_storage_info():
                raise CliError(
                    f"Storage type 's3' supports the options"
                    f" {Argument.to_flag_name(Arguments.ROLE_ARN)},"
                    f" {Argument.to_flag_name(Arguments.REGION)},"
                    f" {Argument.to_flag_name(Arguments.EXTERNAL_ID)},"
                    f" {Argument.to_flag_name(Arguments.USER_ARN)},"
                    f" {Argument.to_flag_name(Arguments.ENDPOINT)},"
                    f" {Argument.to_flag_name(Arguments.ENDPOINT_INTERNAL)},"
                    f" {Argument.to_flag_name(Arguments.KMS_KEY_CURRENT)},"
                    f" {Argument.to_flag_name(Arguments.KMS_KEY_ALLOWED)},"
                    f" {Argument.to_flag_name(Arguments.KMS_KEY_ENCRYPTION)},"
                    f" {Argument.to_flag_name(Arguments.KMS_KEY_DECRYPTION)},"
                    f" {Argument.to_flag_name(Arguments.STS_ENDPOINT)},"
                    f" {Argument.to_flag_name(Arguments.STS_UNAVAILABLE)},"
                    f" {Argument.to_flag_name(Arguments.KMS_UNAVAILABLE)},"
                    f" {Argument.to_flag_name(Arguments.PATH_STYLE_ACCESS)}, and"
                    f" {Argument.to_flag_name(Arguments.STORAGE_NAME)}"
                )
        elif self.storage_type == StorageType.AZURE.value:
            if not self.tenant_id:
                raise CliError(
                    "Missing required argument for storage type 'azure': "
                    f" {Argument.to_flag_name(Arguments.TENANT_ID)}"
                )
            if self._has_aws_storage_info() or self._has_gcs_storage_info():
                raise CliError(
                    "Storage type 'azure' supports the options"
                    f" {Argument.to_flag_name(Arguments.TENANT_ID)},"
                    f" {Argument.to_flag_name(Arguments.MULTI_TENANT_APP_NAME)},"
                    f" {Argument.to_flag_name(Arguments.CONSENT_URL)}, and"
                    f" {Argument.to_flag_name(Arguments.STORAGE_NAME)}"
                )
        elif self.storage_type == StorageType.GCS.value:
            if self._has_aws_storage_info() or self._has_azure_storage_info():
                raise CliError(
                    "Storage type 'gcs' supports the storage credential"
                    f" {Argument.to_flag_name(Arguments.SERVICE_ACCOUNT)} and"
                    f" {Argument.to_flag_name(Arguments.STORAGE_NAME)}"
                )
        elif self.storage_type == StorageType.FILE.value:
            if (
                self._has_aws_storage_info()
                or self._has_azure_storage_info()
                or self._has_gcs_storage_info()
            ):
                raise CliError(
                    "Storage type 'file' does not support any additional options"
                )

    def _has_aws_storage_info(self) -> bool:
        return bool(
            self.role_arn
            or self.external_id
            or self.user_arn
            or self.region
            or self.endpoint
            or self.endpoint_internal
            or self.sts_endpoint
            or self.current_kms_key
            or self.allowed_kms_keys
            or self.encryption_keys
            or self.decryption_keys
            or self.path_style_access
            or self.sts_unavailable
            or self.kms_unavailable
        )

    def _has_azure_storage_info(self) -> bool:
        return bool(
            self.tenant_id
            or self.multi_tenant_app_name
            or self.consent_url
            or self.hierarchical
        )

    def _has_gcs_storage_info(self) -> bool:
        return bool(self.service_account)

    @staticmethod
    def _require_s3(storage_info: StorageConfigInfo, flag: str) -> None:
        # Note: We have to lowercase the returned value because the server enum
        # is uppercase but we defined the StorageType enums as lowercase.
        storage_type = storage_info.storage_type
        if storage_type.lower() != StorageType.S3.value:
            raise CliError(f"{flag} requires S3 storage_type, got: {storage_type}")

    def _build_storage_config_info(self) -> Optional[StorageConfigInfo]:
        config = None
        if self.storage_type == StorageType.S3.value:
            config = AwsStorageConfigInfo(
                storage_type=self.storage_type.upper(),
                storage_name=self.storage_name,
                allowed_locations=self.allowed_locations,
                role_arn=self.role_arn,
                external_id=self.external_id,
                user_arn=self.user_arn,
                region=self.region,
                endpoint=self.endpoint,
                endpoint_internal=self.endpoint_internal,
                sts_endpoint=self.sts_endpoint,
                sts_unavailable=self.sts_unavailable,
                kms_unavailable=self.kms_unavailable,
                path_style_access=self.path_style_access,
                current_kms_key=self.current_kms_key,
                allowed_kms_keys=self.allowed_kms_keys,
                encryption_keys=self.encryption_keys,
                decryption_keys=self.decryption_keys,
            )
        elif self.storage_type == StorageType.AZURE.value:
            config = AzureStorageConfigInfo(
                storage_type=self.storage_type.upper(),
                storage_name=self.storage_name,
                allowed_locations=self.allowed_locations,
                tenant_id=self.tenant_id,
                multi_tenant_app_name=self.multi_tenant_app_name,
                consent_url=self.consent_url,
                hierarchical=self.hierarchical,
            )
        elif self.storage_type == StorageType.GCS.value:
            config = GcpStorageConfigInfo(
                storage_type=self.storage_type.upper(),
                storage_name=self.storage_name,
                allowed_locations=self.allowed_locations,
                gcs_service_account=self.service_account,
            )
        elif self.storage_type == StorageType.FILE.value:
            config = StorageConfigInfo(
                storage_type=self.storage_type.upper(),
                storage_name=self.storage_name,
                allowed_locations=self.allowed_locations,
            )
        return config

    def _build_connection_config_info(
        self,
    ) -> Optional[
        Union[
            HadoopConnectionConfigInfo,
            IcebergRestConnectionConfigInfo,
            HiveConnectionConfigInfo,
        ]
    ]:
        if self.catalog_type != CatalogType.EXTERNAL.value:
            return None

        auth_params = None
        if self.catalog_authentication_type == AuthenticationType.OAUTH.value:
            auth_params = OAuthClientCredentialsParameters(
                authentication_type=self.catalog_authentication_type.upper(),
                token_uri=self.catalog_token_uri,
                client_id=self.catalog_client_id,
                client_secret=SecretStr(self.catalog_client_secret),
                scopes=self.catalog_client_scopes,
            )
        elif self.catalog_authentication_type == AuthenticationType.BEARER.value:
            auth_params = BearerAuthenticationParameters(
                authentication_type=self.catalog_authentication_type.upper(),
                bearer_token=SecretStr(self.catalog_bearer_token),
            )
        elif self.catalog_authentication_type == AuthenticationType.GCP.value:
            auth_params = GcpAuthenticationParameters(
                authentication_type=self.catalog_authentication_type.upper()
            )
        elif self.catalog_authentication_type == AuthenticationType.SIGV4.value:
            auth_params = SigV4AuthenticationParameters(
                authentication_type=self.catalog_authentication_type.upper(),
                role_arn=self.catalog_role_arn,
                role_session_name=self.catalog_role_session_name,
                external_id=self.catalog_external_id,
                signing_region=self.catalog_signing_region,
                signing_name=self.catalog_signing_name,
            )
        elif self.catalog_authentication_type == AuthenticationType.IMPLICIT.value:
            auth_params = ImplicitAuthenticationParameters(
                authentication_type=self.catalog_authentication_type.upper()
            )
        elif self.catalog_authentication_type is not None:
            raise CliError(
                f"Unknown authentication type: {self.catalog_authentication_type}"
            )

        service_identity = None
        if self.catalog_service_identity_type == ServiceIdentityType.AWS_IAM.value:
            service_identity = AwsIamServiceIdentityInfo(
                identity_type=self.catalog_service_identity_type.upper(),
                iam_arn=self.catalog_service_identity_iam_arn,
            )
        elif self.catalog_service_identity_type is not None:
            raise CliError(
                f"Unknown service identity type: {self.catalog_service_identity_type}"
            )

        config = None
        if self.catalog_connection_type == CatalogConnectionType.HADOOP.value:
            config = HadoopConnectionConfigInfo(
                connection_type=self.catalog_connection_type.upper(),
                uri=self.catalog_uri,
                authentication_parameters=auth_params,
                service_identity=service_identity,
                warehouse=self.hadoop_warehouse,
            )
        elif self.catalog_connection_type == CatalogConnectionType.ICEBERG.value:
            config = IcebergRestConnectionConfigInfo(
                connection_type=self.catalog_connection_type.upper().replace("-", "_"),
                uri=self.catalog_uri,
                authentication_parameters=auth_params,
                service_identity=service_identity,
                remote_catalog_name=self.iceberg_remote_catalog_name,
            )
        elif self.catalog_connection_type == CatalogConnectionType.HIVE.value:
            config = HiveConnectionConfigInfo(
                connection_type=self.catalog_connection_type.upper(),
                uri=self.catalog_uri,
                authentication_parameters=auth_params,
                service_identity=service_identity,
                warehouse=self.hive_warehouse,
            )
        elif self.catalog_connection_type is not None:
            raise CliError(
                f"Unknown catalog connection type: {self.catalog_connection_type}"
            )
        return config

    def execute(self, api: PolarisDefaultApi) -> None:
        catalog_type = cast(str, self.catalog_type)
        catalog_name = cast(str, self.catalog_name)

        if self.catalogs_subcommand == Subcommands.CREATE:
            storage_config = self._build_storage_config_info()
            connection_config = self._build_connection_config_info()
            if self.catalog_type == CatalogType.EXTERNAL.value:
                request = CreateCatalogRequest(
                    catalog=ExternalCatalog(
                        type=catalog_type.upper(),
                        name=catalog_name,
                        storage_config_info=storage_config,
                        properties=CatalogProperties(
                            default_base_location=self.default_base_location,
                            additional_properties=self.properties,
                        ),
                        connection_config_info=connection_config,
                    )
                )
            else:
                request = CreateCatalogRequest(
                    catalog=PolarisCatalog(
                        type=catalog_type.upper(),
                        name=catalog_name,
                        storage_config_info=storage_config,
                        properties=CatalogProperties(
                            default_base_location=self.default_base_location,
                            additional_properties=self.properties,
                        ),
                        connection_config_info=connection_config,
                    )
                )
            api.create_catalog(request)
        elif self.catalogs_subcommand == Subcommands.DELETE:
            api.delete_catalog(catalog_name)
        elif self.catalogs_subcommand == Subcommands.GET:
            print(api.get_catalog(catalog_name).to_json())
        elif self.catalogs_subcommand == Subcommands.LIST:
            for catalog in api.list_catalogs().catalogs:
                print(catalog.to_json())
        elif self.catalogs_subcommand == Subcommands.UPDATE:
            catalog = api.get_catalog(catalog_name)

            if (
                self.default_base_location
                or self.set_properties
                or self.remove_properties
            ):
                new_default_base_location = (
                    self.default_base_location
                    or catalog.properties.default_base_location
                )
                new_additional_properties = (
                    catalog.properties.additional_properties or {}
                )

                # Add or update all entries specified in set_properties
                if self.set_properties:
                    new_additional_properties = {
                        **new_additional_properties,
                        **self.set_properties,
                    }

                # Remove all keys specified in remove_properties
                if self.remove_properties:
                    for to_remove in self.remove_properties:
                        new_additional_properties.pop(to_remove, None)

                catalog.properties = CatalogProperties(
                    default_base_location=new_default_base_location,
                    additional_properties=new_additional_properties,
                )

            if (
                self._has_aws_storage_info()
                or self._has_azure_storage_info()
                or self._has_gcs_storage_info()
                or self.allowed_locations
                or self.storage_name is not None
            ):
                # We must first reconstitute local storage-config related settings from the existing
                # catalog to properly construct the complete updated storage-config
                updated_storage_info = catalog.storage_config_info

                # In order to apply mutations client-side, we can't just use the base
                # _build_storage_config_info helper; instead, each allowed updatable field defined
                # in option_tree.py should be applied individually against the existing
                # storage_config_info here.
                if self.storage_name:
                    updated_storage_info.storage_name = self.storage_name
                if self.allowed_locations:
                    updated_storage_info.allowed_locations = (
                        updated_storage_info.allowed_locations or []
                    ) + self.allowed_locations

                if self.region:
                    self._require_s3(updated_storage_info, "--region")
                    updated_storage_info.region = self.region

                if self.sts_unavailable:
                    self._require_s3(updated_storage_info, "--no-sts")
                    updated_storage_info.sts_unavailable = self.sts_unavailable

                if self.kms_unavailable:
                    self._require_s3(updated_storage_info, "--no-kms")
                    updated_storage_info.kms_unavailable = self.kms_unavailable

                request = UpdateCatalogRequest(
                    current_entity_version=catalog.entity_version,
                    properties=catalog.properties.to_dict(),
                    storage_config_info=updated_storage_info,
                )
            else:
                request = UpdateCatalogRequest(
                    current_entity_version=catalog.entity_version,
                    properties=catalog.properties.to_dict(),
                )

            api.update_catalog(catalog_name, request)
        elif self.catalogs_subcommand == Subcommands.SUMMARIZE:
            self._generate_summary(api)
        else:
            raise CliError(f"{self.catalogs_subcommand} is not supported in the CLI")

    def _generate_summary(self, api: PolarisDefaultApi) -> None:
        catalog_name = cast(str, self.catalog_name)
        print(f"Catalog: {catalog_name}")
        print("-" * 80)
        # Metadata
        catalog = api.get_catalog(catalog_name)
        print("Metadata")
        print(f"  {'Type:':<30} {catalog.type}")
        storage_info = catalog.storage_config_info
        print(f"  {'Storage Type:':<30} {storage_info.storage_type}")
        print(f"  {'Base Location:':<30} {catalog.properties.default_base_location}")
        print(
            f"  {'Allowed Locations:':<30} {', '.join(storage_info.allowed_locations or [])}"
        )
        print(f"  {'Created:':<30} {format_timestamp(catalog.create_timestamp)}")
        print(f"  {'Modified:':<30} {format_timestamp(catalog.last_update_timestamp)}")
        print(f"  {'Version:':<30} {catalog.entity_version}")

        # Inventory
        catalog_api = IcebergCatalogAPI(get_catalog_api_client(api))
        total_ns, total_tables, total_views = self._get_sub_entities_count(catalog_api)
        print("\nInventory")
        print(f"  {'Namespaces:':<30} {total_ns}")
        print(f"  {'Tables:':<30} {total_tables}")
        print(f"  {'Views:':<30} {total_views}")

        # Access Control
        catalog_roles = api.list_catalog_roles(catalog_name).roles or []
        principal_roles_names = set()
        for catalog_role in catalog_roles:
            pr_resp = api.list_assignee_principal_roles_for_catalog_role(
                catalog_name, catalog_role.name
            )
            roles = pr_resp.roles or []
            for pr in roles:
                principal_roles_names.add(pr.name)
        print("\nAccess Control")
        print(f"  {'Catalog Roles:':<30} {len(catalog_roles)}")
        print(f"  {'Assigned Principal Roles:':<30} {len(principal_roles_names)}")

        # Policies
        policy_api = PolicyAPI(catalog_api.api_client)
        policies_resp = policy_api.get_applicable_policies(prefix=catalog_name)
        print("\nApplicable Policies")
        applicable_policies = policies_resp.applicable_policies or []
        if applicable_policies:
            for policy in sorted(applicable_policies, key=lambda x: x.name):
                print(f"  - {policy.name}")
        else:
            print("  No applicable policies")
        print("-" * 80)

    def _get_sub_entities_count(
        self, catalog_api: IcebergCatalogAPI
    ) -> Tuple[int, int, int]:
        catalog_name = cast(str, self.catalog_name)

        def count_entities(func: Callable, ns_str: str) -> int:
            try:
                total = 0
                for resp in paginate(
                    func,
                    page_size=self.page_size,
                    prefix=catalog_name,
                    namespace=ns_str,
                ):
                    total += len(resp.identifiers or [])
                return total
            except Exception as e:
                print(
                    f"Warning: Could not list entity for namespace {ns_str}: {e}",
                )
                return 0

        def recursive(parent: Optional[str] = None) -> Tuple[int, int, int]:
            total_ns, total_tables, total_views = 0, 0, 0
            for resp in paginate(
                catalog_api.list_namespaces,
                page_size=self.page_size,
                prefix=catalog_name,
                parent=parent,
            ):
                for ns in resp.namespaces or []:
                    total_ns += 1
                    ns_str = UNIT_SEPARATOR.join(ns)
                    total_tables += count_entities(catalog_api.list_tables, ns_str)
                    total_views += count_entities(catalog_api.list_views, ns_str)
                    ns_cnt, tables_cnt, views_cnt = recursive(ns_str)
                    total_ns += ns_cnt
                    total_tables += tables_cnt
                    total_views += views_cnt
            return total_ns, total_tables, total_views

        return recursive()
