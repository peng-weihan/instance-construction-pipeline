#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

from unittest.mock import patch, MagicMock
from cli_test_utils import CLITestBase
from apache_polaris.cli.constants import UNIT_SEPARATOR
from apache_polaris.cli.exceptions import CLI_ERROR_EXIT_CODE
from apache_polaris.cli.polaris_cli import PolarisCli
from apache_polaris.sdk.catalog.exceptions import ApiException
from apache_polaris.sdk.catalog.models import RegisterTableRequest


class TestTablesCommand(CLITestBase):
    def test_table_validation(self) -> None:
        mock_client = self.build_mock_client()
        # Missing catalog/namespace
        self.check_exception(
            lambda: self.mock_execute(mock_client, ["tables", "list"]),
            "Missing required argument",
        )
        # Empty table name
        self.check_exception(
            lambda: self.mock_execute(
                mock_client,
                ["tables", "get", " ", "--catalog", "my-catalog", "--namespace", "ns1"],
            ),
            "The table name cannot be empty",
        )

    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_list(self, mock_iceberg_api_class: MagicMock) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        mock_iceberg_api.list_tables.return_value.identifiers = []
        self.mock_execute(
            mock_client,
            ["tables", "list", "--catalog", "my-catalog", "--namespace", "ns1.ns2"],
        )
        mock_iceberg_api.list_tables.assert_called_once_with(
            prefix="my-catalog", namespace=UNIT_SEPARATOR.join(["ns1", "ns2"])
        )

    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_list_with_paginate(self, mock_iceberg_api_class: MagicMock) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        ids = [MagicMock(to_json=MagicMock(return_value="{}")) for _ in range(3)]
        page1 = MagicMock(identifiers=ids[:2], next_page_token="token")
        page2 = MagicMock(identifiers=[ids[2]], next_page_token=None)
        mock_iceberg_api.list_tables.side_effect = [page1, page2]
        self.mock_execute(
            mock_client,
            [
                "tables",
                "list",
                "--catalog",
                "my-catalog",
                "--namespace",
                "ns1",
                "--page-size",
                "2",
            ],
        )
        self.assertEqual(mock_iceberg_api.list_tables.call_count, 2)
        mock_iceberg_api.list_tables.assert_any_call(
            prefix="my-catalog", namespace="ns1", page_size=2, page_token=""
        )
        mock_iceberg_api.list_tables.assert_any_call(
            prefix="my-catalog", namespace="ns1", page_size=2, page_token="token"
        )

    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_list_paginated_root_arg_position(
        self, mock_iceberg_api_class: MagicMock
    ) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        id1 = MagicMock(to_json=MagicMock(return_value="{}"))
        page = MagicMock(identifiers=[id1], next_page_token=None)
        mock_iceberg_api.list_tables.return_value = page
        self.mock_execute(
            mock_client,
            [
                "--page-size",
                "50",
                "tables",
                "list",
                "--catalog",
                "my-catalog",
                "--namespace",
                "ns1",
            ],
        )
        mock_iceberg_api.list_tables.assert_called_once_with(
            prefix="my-catalog", namespace="ns1", page_size=50, page_token=""
        )

    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_get(self, mock_iceberg_api_class: MagicMock) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        mock_iceberg_api.load_table.return_value.to_json.return_value = "{}"
        self.mock_execute(
            mock_client,
            [
                "tables",
                "get",
                "my_table",
                "--catalog",
                "my-catalog",
                "--namespace",
                "ns1",
            ],
        )
        mock_iceberg_api.load_table.assert_called_once_with(
            prefix="my-catalog", namespace="ns1", table="my_table"
        )

    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_delete(self, mock_iceberg_api_class: MagicMock) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        self.mock_execute(
            mock_client,
            [
                "tables",
                "delete",
                "my_table",
                "--catalog",
                "my-catalog",
                "--namespace",
                "ns1",
            ],
        )
        mock_iceberg_api.drop_table.assert_called_once_with(
            prefix="my-catalog",
            namespace="ns1",
            table="my_table",
            purge_requested=False,
        )

    @patch("apache_polaris.cli.polaris_cli.PolarisCli.print_api_exception")
    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    @patch("apache_polaris.cli.polaris_cli.PolarisDefaultApi")
    @patch("apache_polaris.cli.polaris_cli.ApiClientBuilder.get_api_client")
    def test_table_api_errors_exit_with_runtime_failure(
        self,
        _mock_get_api_client: MagicMock,
        mock_default_api: MagicMock,
        mock_iceberg_api_class: MagicMock,
        mock_print_api_exception: MagicMock,
    ) -> None:
        mock_default_api.return_value = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        cases = [
            ("list_tables", ["tables", "list"]),
            ("load_table", ["tables", "get", "my_table"]),
            ("drop_table", ["tables", "delete", "my_table"]),
        ]

        for api_method, args in cases:
            with self.subTest(api_method=api_method):
                method = getattr(mock_iceberg_api, api_method)
                method.side_effect = ApiException(status=404, reason="Not Found")

                with self.assertRaises(SystemExit) as cm:
                    PolarisCli.execute(
                        [*args, "--catalog", "my-catalog", "--namespace", "ns1"]
                    )

                self.assertEqual(cm.exception.code, CLI_ERROR_EXIT_CODE)
                mock_print_api_exception.assert_called_once()
                method.side_effect = None
                mock_print_api_exception.reset_mock()

    @patch("apache_polaris.cli.command.tables.PolicyAPI")
    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_summarize(
        self, mock_iceberg_api_class: MagicMock, mock_policy_api_class: MagicMock
    ) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        mock_policy_api = mock_policy_api_class.return_value

        self.mock_execute(
            mock_client,
            [
                "tables",
                "summarize",
                "my_table",
                "--catalog",
                "my-catalog",
                "--namespace",
                "ns1",
            ],
        )
        mock_iceberg_api.load_table.assert_called_with(
            prefix="my-catalog", namespace="ns1", table="my_table"
        )
        mock_policy_api.get_applicable_policies.assert_called_with(
            prefix="my-catalog", namespace="ns1", target_name="my_table"
        )

    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_register(self, mock_iceberg_api_class: MagicMock) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value

        self.mock_execute(
            mock_client,
            [
                "tables",
                "register",
                "my_table",
                "--catalog",
                "my-catalog",
                "--namespace",
                "ns1",
                "--metadata-location",
                "s3://bucket/ns1/my_table/metadata/00001-abcd.metadata.json",
            ],
        )
        mock_iceberg_api.register_table.assert_called_once()
        kwargs = mock_iceberg_api.register_table.call_args.kwargs
        self.assertEqual(kwargs["prefix"], "my-catalog")
        self.assertEqual(kwargs["namespace"], "ns1")
        request = kwargs["register_table_request"]
        self.assertIsInstance(request, RegisterTableRequest)
        self.assertEqual(request.name, "my_table")
        self.assertEqual(
            request.metadata_location,
            "s3://bucket/ns1/my_table/metadata/00001-abcd.metadata.json",
        )
        self.assertFalse(request.overwrite)

    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_register_with_overwrite(
        self, mock_iceberg_api_class: MagicMock
    ) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value

        self.mock_execute(
            mock_client,
            [
                "tables",
                "register",
                "my_table",
                "--catalog",
                "my-catalog",
                "--namespace",
                "ns1",
                "--metadata-location",
                "s3://bucket/ns1/my_table/metadata/00001-abcd.metadata.json",
                "--overwrite",
            ],
        )
        mock_iceberg_api.register_table.assert_called_once()
        kwargs = mock_iceberg_api.register_table.call_args.kwargs
        self.assertEqual(kwargs["prefix"], "my-catalog")
        self.assertEqual(kwargs["namespace"], "ns1")
        request = kwargs["register_table_request"]
        self.assertIsInstance(request, RegisterTableRequest)
        self.assertEqual(request.name, "my_table")
        self.assertEqual(
            request.metadata_location,
            "s3://bucket/ns1/my_table/metadata/00001-abcd.metadata.json",
        )
        self.assertTrue(request.overwrite)

    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_register_missing_metadata_location(
        self, mock_iceberg_api_class: MagicMock
    ) -> None:
        mock_client = self.build_mock_client()

        self.check_exception(
            lambda: self.mock_execute(
                mock_client,
                [
                    "tables",
                    "register",
                    "my_table",
                    "--catalog",
                    "my-catalog",
                    "--namespace",
                    "ns1",
                ],
            ),
            "--metadata-location",
        )

    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_register_forwards_location_without_scheme(
        self, mock_iceberg_api_class: MagicMock
    ) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value

        self.mock_execute(
            mock_client,
            [
                "tables",
                "register",
                "my_table",
                "--catalog",
                "my-catalog",
                "--namespace",
                "ns1",
                "--metadata-location",
                "/bucket/ns1/my_table/metadata/00001-abcd.metadata.json",
            ],
        )
        request = mock_iceberg_api.register_table.call_args.kwargs[
            "register_table_request"
        ]
        self.assertEqual(
            request.metadata_location,
            "/bucket/ns1/my_table/metadata/00001-abcd.metadata.json",
        )

    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_register_forwards_windows_drive_path(
        self, mock_iceberg_api_class: MagicMock
    ) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value

        self.mock_execute(
            mock_client,
            [
                "tables",
                "register",
                "my_table",
                "--catalog",
                "my-catalog",
                "--namespace",
                "ns1",
                "--metadata-location",
                "C:\\data\\my_table\\metadata\\00001-abcd.metadata.json",
            ],
        )
        request = mock_iceberg_api.register_table.call_args.kwargs[
            "register_table_request"
        ]
        self.assertEqual(
            request.metadata_location,
            "C:\\data\\my_table\\metadata\\00001-abcd.metadata.json",
        )

    @patch("apache_polaris.cli.command.tables.IcebergCatalogAPI")
    def test_table_register_strips_metadata_location_whitespace(
        self, mock_iceberg_api_class: MagicMock
    ) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value

        self.mock_execute(
            mock_client,
            [
                "tables",
                "register",
                "my_table",
                "--catalog",
                "my-catalog",
                "--namespace",
                "ns1",
                "--metadata-location",
                "  s3://bucket/ns1/my_table/metadata/00001-abcd.metadata.json  ",
            ],
        )
        request = mock_iceberg_api.register_table.call_args.kwargs[
            "register_table_request"
        ]
        self.assertEqual(
            request.metadata_location,
            "s3://bucket/ns1/my_table/metadata/00001-abcd.metadata.json",
        )
