#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#
from dataclasses import dataclass, field
from typing import Dict, Optional, List, cast

from pydantic import StrictStr

from apache_polaris.cli.command import Command
from apache_polaris.cli.exceptions import CliError
from apache_polaris.cli.constants import Subcommands, Arguments
from apache_polaris.cli.options.option_tree import Argument
from apache_polaris.sdk.management import (
    PolarisDefaultApi,
    CreateCatalogRoleRequest,
    CatalogRole,
    UpdateCatalogRoleRequest,
    GrantCatalogRoleRequest,
)
from apache_polaris.cli.command.utils import format_timestamp


@dataclass
class CatalogRolesCommand(Command):
    """
    A Command implementation to represent `polaris catalog-roles`. The instance attributes correspond to parameters
    that can be provided to various subcommands, except `catalog_roles_subcommand` which represents the subcommand
    itself.

    Example commands:
        * polaris catalog-roles create --catalog bronze_catalog cat_role
        * polaris catalog-roles list --catalog bronze_catalog --principal-role data-analyst
        * polaris catalog-roles grant --catalog bronze_catalog --principal-role data-engineer etl_role
    """

    catalog_roles_subcommand: str
    catalog_name: Optional[str] = None
    catalog_role_name: Optional[str] = None
    principal_role_name: Optional[str] = None
    properties: Optional[Dict[str, StrictStr]] = field(default_factory=dict)
    set_properties: Optional[Dict[str, StrictStr]] = field(default_factory=dict)
    remove_properties: Optional[List[str]] = None

    def __post_init__(self) -> None:
        if self.properties is None:
            self.properties = {}
        if self.set_properties is None:
            self.set_properties = {}

    def validate(self) -> None:
        if not self.catalog_name:
            raise CliError(
                f"Missing required argument: {Argument.to_flag_name(Arguments.CATALOG)}"
            )

        if self.catalog_roles_subcommand in {
            Subcommands.CREATE,
            Subcommands.DELETE,
            Subcommands.GET,
            Subcommands.UPDATE,
            Subcommands.GRANT,
            Subcommands.REVOKE,
            Subcommands.SUMMARIZE,
        }:
            if not self.catalog_role_name:
                raise CliError(
                    f"Missing required argument: {Argument.to_flag_name(Arguments.CATALOG_ROLE)}"
                )

        if self.catalog_roles_subcommand in {Subcommands.GRANT, Subcommands.REVOKE}:
            if not self.principal_role_name:
                raise CliError(
                    f"Missing required argument: {Argument.to_flag_name(Arguments.PRINCIPAL_ROLE)}"
                )

    def execute(self, api: PolarisDefaultApi) -> None:
        catalog_name = cast(str, self.catalog_name)
        catalog_role_name = cast(str, self.catalog_role_name)

        if self.catalog_roles_subcommand == Subcommands.CREATE:
            request = CreateCatalogRoleRequest(
                catalog_role=CatalogRole(
                    name=catalog_role_name, properties=self.properties
                )
            )
            api.create_catalog_role(catalog_name, request)
        elif self.catalog_roles_subcommand == Subcommands.DELETE:
            api.delete_catalog_role(catalog_name, catalog_role_name)
        elif self.catalog_roles_subcommand == Subcommands.GET:
            print(api.get_catalog_role(catalog_name, catalog_role_name).to_json())
        elif self.catalog_roles_subcommand == Subcommands.LIST:
            if self.principal_role_name:
                for catalog_role in api.list_catalog_roles_for_principal_role(
                    cast(str, self.principal_role_name), catalog_name
                ).roles:
                    print(catalog_role.to_json())
            else:
                for catalog_role in api.list_catalog_roles(catalog_name).roles:
                    print(catalog_role.to_json())
        elif self.catalog_roles_subcommand == Subcommands.UPDATE:
            catalog_role = api.get_catalog_role(catalog_name, catalog_role_name)
            new_properties = catalog_role.properties or {}

            # Add or update all entries specified in set_properties
            if self.set_properties:
                new_properties = {**new_properties, **self.set_properties}

            # Remove all keys specified in remove_properties
            if self.remove_properties:
                for to_remove in self.remove_properties:
                    new_properties.pop(to_remove, None)

            request = UpdateCatalogRoleRequest(
                current_entity_version=catalog_role.entity_version,
                properties=new_properties,
            )
            api.update_catalog_role(catalog_name, catalog_role_name, request)
        elif self.catalog_roles_subcommand == Subcommands.GRANT:
            request = GrantCatalogRoleRequest(
                catalog_role=CatalogRole(name=catalog_role_name),
                properties=self.properties,
            )
            api.assign_catalog_role_to_principal_role(
                cast(str, self.principal_role_name), catalog_name, request
            )
        elif self.catalog_roles_subcommand == Subcommands.REVOKE:
            api.revoke_catalog_role_from_principal_role(
                cast(str, self.principal_role_name), catalog_name, catalog_role_name
            )
        elif self.catalog_roles_subcommand == Subcommands.SUMMARIZE:
            self._generate_summary(api)
        else:
            raise CliError(
                f"{self.catalog_roles_subcommand} is not supported in the CLI"
            )

    def _generate_summary(self, api: PolarisDefaultApi) -> None:
        catalog_name = cast(str, self.catalog_name)
        catalog_role_name = cast(str, self.catalog_role_name)
        grants = (
            api.list_grants_for_catalog_role(catalog_name, catalog_role_name).grants
            or []
        )
        print(f"Catalog Role: {catalog_role_name} [Catalog: {catalog_name}]")
        print("-" * 80)
        # Metadata
        role = api.get_catalog_role(catalog_name, catalog_role_name)
        print("Metadata")
        print(f"  {'Created:':<30} {format_timestamp(role.create_timestamp)}")
        print(f"  {'Modified:':<30} {format_timestamp(role.last_update_timestamp)}")
        print(f"  {'Version:':<30} {role.entity_version}")

        # Assignments
        principal_roles = (
            api.list_assignee_principal_roles_for_catalog_role(
                catalog_name, catalog_role_name
            ).roles
            or []
        )
        print("\nAssignments")
        print(f"  {'Assigned Principal Roles:':<30} {len(principal_roles)}")
        print(f"  {'Total Grants:':<30} {len(grants)}")

        # Privileges
        print("\nPrivileges")
        if not grants:
            print("  No grants found")
        else:
            for grant in sorted(
                grants, key=lambda x: (str(x.privilege), str(x.namespace))
            ):
                privilege = grant.privilege.value
                resource = ""
                if grant.type == "namespace":
                    resource = f" on {'.'.join(grant.namespace)}"
                elif grant.type == "table":
                    resource = f" on {'.'.join(grant.namespace)}.{grant.table}"
                elif grant.type == "view":
                    resource = f" on {'.'.join(grant.namespace)}.{grant.view}"
                print(f"  - {privilege}{resource}")
        print("-" * 80)
