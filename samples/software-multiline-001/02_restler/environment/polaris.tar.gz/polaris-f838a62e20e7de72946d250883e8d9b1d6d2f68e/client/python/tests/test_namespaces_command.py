#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

import io
from unittest.mock import patch, MagicMock, call
from cli_test_utils import CLITestBase
from apache_polaris.cli.command.namespaces import NamespacesCommand
from apache_polaris.cli.constants import UNIT_SEPARATOR, Subcommands


class TestNamespacesCommand(CLITestBase):
    def test_namespace_validation(self) -> None:
        mock_client = self.build_mock_client()
        # Missing --catalog flag
        self.check_exception(
            lambda: self.mock_execute(mock_client, ["namespaces", "list"]),
            "Missing required argument: --catalog",
        )
        # Missing positional namespace
        for sub in ["create", "delete", "get", "update", "summarize"]:
            with self.subTest(subcommand=sub):
                with self.assertRaises(SystemExit):
                    self.mock_execute(
                        mock_client, ["namespaces", sub, "--catalog", "my_catalog"]
                    )
        # update with nothing to change
        self.check_exception(
            lambda: self.mock_execute(
                mock_client, ["namespaces", "update", "ns1", "--catalog", "my_catalog"]
            ),
            "At least one of --set-property or --remove-property is required",
        )

    def test_namespace_input_normalization(self) -> None:
        cmd = NamespacesCommand(
            namespaces_subcommand=Subcommands.LIST,
            catalog="my_cat",
            namespace=None,
            parent=None,
            properties=None,
        )
        # __post_init__ should not normalized these
        self.assertIsNone(cmd.namespace)
        self.assertIsNone(cmd.parent)
        # __post_init__ should normalized these
        self.assertEqual(cmd.properties, {})

    @patch("apache_polaris.cli.command.namespaces.IcebergCatalogAPI")
    def test_namespace_create(self, mock_iceberg_api_class: MagicMock) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        self.mock_execute(
            mock_client,
            [
                "namespaces",
                "create",
                "ns1.ns2",
                "--catalog",
                "my-catalog",
                "--location",
                "s3://bucket/path",
                "--property",
                "k=v",
            ],
        )
        mock_iceberg_api.create_namespace.assert_called_once()
        _, kwargs = mock_iceberg_api.create_namespace.call_args
        self.assertEqual(kwargs["prefix"], "my-catalog")
        self.assertEqual(kwargs["create_namespace_request"].namespace, ["ns1", "ns2"])
        self.assertEqual(
            kwargs["create_namespace_request"].properties,
            {"k": "v", "location": "s3://bucket/path"},
        )

    @patch("apache_polaris.cli.command.namespaces.IcebergCatalogAPI")
    def test_namespace_list(self, mock_iceberg_api_class: MagicMock) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        self.mock_execute(
            mock_client, ["namespaces", "list", "--catalog", "my-catalog"]
        )
        mock_iceberg_api.list_namespaces.assert_called_with(
            prefix="my-catalog", parent=None
        )

        self.mock_execute(
            mock_client,
            ["namespaces", "list", "--catalog", "my-catalog", "--parent", "ns1"],
        )
        mock_iceberg_api.list_namespaces.assert_called_with(
            prefix="my-catalog", parent="ns1"
        )


    @patch("apache_polaris.cli.command.namespaces.IcebergCatalogAPI")
    def test_namespace_with_paginate(self, mock_iceberg_api_class: MagicMock) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        page1 = MagicMock(namespaces=[["a"], ["b"]], next_page_token="token")
        page2 = MagicMock(namespaces=[["c"]], next_page_token=None)
        mock_iceberg_api.list_namespaces.side_effect = [page1, page2]
        with patch("sys.stdout", new_callable=io.StringIO) as mock_stdout:
            self.mock_execute(
                mock_client, ["namespaces", "list", "--catalog", "my-catalog", "--page-size", "2"],
            )
        # First request opts into pagination with an empty page_token and the returned next_page_token
        # is used for the follow-up request.
        mock_iceberg_api.list_namespaces.assert_has_calls(
            [
                call(prefix="my-catalog", parent=None, page_size=2, page_token=""),
                call(prefix="my-catalog", parent=None, page_size=2, page_token="token"),
            ]
        )
        self.assertEqual(mock_iceberg_api.list_namespaces.call_count, 2)
        # All namespace across both pages should be collected
        output_lines = mock_stdout.getvalue().splitlines()
        self.assertEqual(
            output_lines,
            [
                '{"namespace": "a"}',
                '{"namespace": "b"}',
                '{"namespace": "c"}',
            ]
        )

    def test_namespace_rejects_invalid_page_size(self) -> None:
        mock_client = self.build_mock_client()
        for bad in (0, -1):
            with self.subTest(page_size=bad):
                self.check_exception(
                    lambda: self.mock_execute(
                        mock_client,
                        [
                            "--page-size",
                            str(bad),
                            "namespaces",
                            "list",
                            "--catalog",
                            "my-catalog"
                        ],
                    ),
                    "page-size must be a positive integer",
                )

    @patch("apache_polaris.cli.command.namespaces.IcebergCatalogAPI")
    def test_namespace_delete(self, mock_iceberg_api_class: MagicMock) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        self.mock_execute(
            mock_client, ["namespaces", "delete", "ns1.ns2", "--catalog", "my-catalog"]
        )
        mock_iceberg_api.drop_namespace.assert_called_once_with(
            prefix="my-catalog", namespace=UNIT_SEPARATOR.join(["ns1", "ns2"])
        )

    @patch("apache_polaris.cli.command.namespaces.IcebergCatalogAPI")
    def test_namespace_get(self, mock_iceberg_api_class: MagicMock) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        self.mock_execute(
            mock_client, ["namespaces", "get", "ns1.ns2", "--catalog", "my-catalog"]
        )
        mock_iceberg_api.load_namespace_metadata.assert_called_once_with(
            prefix="my-catalog", namespace=UNIT_SEPARATOR.join(["ns1", "ns2"])
        )

    @patch("apache_polaris.cli.command.namespaces.IcebergCatalogAPI")
    def test_namespace_update(self, mock_iceberg_api_class: MagicMock) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        self.mock_execute(
            mock_client,
            [
                "namespaces",
                "update",
                "ns1.ns2",
                "--catalog",
                "my-catalog",
                "--set-property",
                "k1=v1",
                "--set-property",
                "k2=v2",
                "--remove-property",
                "old",
            ],
        )
        mock_iceberg_api.update_properties.assert_called_once()
        _, kwargs = mock_iceberg_api.update_properties.call_args
        self.assertEqual(kwargs["prefix"], "my-catalog")
        self.assertEqual(kwargs["namespace"], UNIT_SEPARATOR.join(["ns1", "ns2"]))
        request = kwargs["update_namespace_properties_request"]
        self.assertEqual(request.updates, {"k1": "v1", "k2": "v2"})
        self.assertEqual(request.removals, ["old"])

    @patch("apache_polaris.cli.command.namespaces.IcebergCatalogAPI")
    def test_namespace_update_remove_only(
        self, mock_iceberg_api_class: MagicMock
    ) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        self.mock_execute(
            mock_client,
            [
                "namespaces",
                "update",
                "ns1",
                "--catalog",
                "my-catalog",
                "--remove-property",
                "a",
                "--remove-property",
                "b",
            ],
        )
        _, kwargs = mock_iceberg_api.update_properties.call_args
        request = kwargs["update_namespace_properties_request"]
        self.assertEqual(request.updates, {})
        self.assertEqual(request.removals, ["a", "b"])

    @patch("apache_polaris.cli.command.namespaces.PolicyAPI")
    @patch("apache_polaris.cli.command.namespaces.IcebergCatalogAPI")
    def test_namespace_summarize(
        self, mock_iceberg_api_class: MagicMock, mock_policy_api_class: MagicMock
    ) -> None:
        mock_client = self.build_mock_client()
        mock_iceberg_api = mock_iceberg_api_class.return_value
        mock_policy_api = mock_policy_api_class.return_value
        self.mock_execute(
            mock_client,
            ["namespaces", "summarize", "ns1.ns2", "--catalog", "my-catalog"],
        )
        mock_iceberg_api.list_namespaces.assert_called_with(
            prefix="my-catalog", parent=UNIT_SEPARATOR.join(["ns1", "ns2"])
        )
        mock_iceberg_api.list_tables.assert_called_with(
            prefix="my-catalog", namespace=UNIT_SEPARATOR.join(["ns1", "ns2"])
        )
        mock_iceberg_api.list_views.assert_called_with(
            prefix="my-catalog", namespace=UNIT_SEPARATOR.join(["ns1", "ns2"])
        )
        mock_policy_api.get_applicable_policies.assert_called_with(
            prefix="my-catalog", namespace=UNIT_SEPARATOR.join(["ns1", "ns2"])
        )
