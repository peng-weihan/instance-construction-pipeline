// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

//! # Examples demonstrating DataFusion's plan serialization via the `datafusion-proto` crate
//!
//! These examples show how to use multiple extension codecs for serialization / deserialization.
//!
//! ## Usage
//! ```bash
//! cargo run --example proto -- [all|composed_extension_codec|expression_deduplication|extension_plan_registry]
//! ```
//!
//! Each subcommand runs a corresponding example:
//! - `all` — run all examples included in this module
//!
//! - `composed_extension_codec`
//!   (file: composed_extension_codec.rs, desc: Use multiple extension codecs for serialization/deserialization)
//!
//! - `expression_deduplication`
//!   (file: expression_deduplication.rs, desc: Example of expression caching/deduplication using the codec decorator pattern)
//!
//! - `extension_plan_registry`
//!   (file: extension_plan_registry.rs, desc: Decode two crates' extension plans by name, with no composed codec)

mod composed_extension_codec;
mod expression_deduplication;
mod extension_plan_registry;

use datafusion::error::{DataFusionError, Result};
use strum::{IntoEnumIterator, VariantNames};
use strum_macros::{Display, EnumIter, EnumString, VariantNames};

#[derive(EnumIter, EnumString, Display, VariantNames)]
#[strum(serialize_all = "snake_case")]
enum ExampleKind {
    All,
    ComposedExtensionCodec,
    ExpressionDeduplication,
    ExtensionPlanRegistry,
}

impl ExampleKind {
    const EXAMPLE_NAME: &str = "proto";

    fn runnable() -> impl Iterator<Item = ExampleKind> {
        ExampleKind::iter().filter(|v| !matches!(v, ExampleKind::All))
    }

    async fn run(&self) -> Result<()> {
        match self {
            ExampleKind::All => {
                for example in ExampleKind::runnable() {
                    println!("Running example: {example}");
                    Box::pin(example.run()).await?;
                }
            }
            ExampleKind::ComposedExtensionCodec => {
                composed_extension_codec::composed_extension_codec()?
            }
            ExampleKind::ExpressionDeduplication => {
                expression_deduplication::expression_deduplication()?
            }
            ExampleKind::ExtensionPlanRegistry => {
                extension_plan_registry::extension_plan_registry()?
            }
        }
        Ok(())
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    let usage = format!(
        "Usage: cargo run --example {} -- [{}]",
        ExampleKind::EXAMPLE_NAME,
        ExampleKind::VARIANTS.join("|")
    );

    let example: ExampleKind = std::env::args()
        .nth(1)
        .unwrap_or_else(|| ExampleKind::All.to_string())
        .parse()
        .map_err(|_| DataFusionError::Execution(format!("Unknown example. {usage}")))?;

    example.run().await
}
