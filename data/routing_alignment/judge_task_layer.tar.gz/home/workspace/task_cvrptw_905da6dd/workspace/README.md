# CVRPTW Solver — Agent Workspace

> 你（Agent）的任务：在本目录内修改源码，构建一个 C++17 二进制 `cvrptw_solver`，求解一组 **56 个** Solomon-100 标准 CVRPTW 实例，目标得分尽量高。

## 1. 题目概述

**问题**：带时间窗的有容量约束车辆路径规划（Capacitated Vehicle Routing Problem with Time Windows，CVRPTW）。
- 给定 1 个仓库 + N 个客户的坐标、需求、服务时间窗 `[e_i, l_i]`、服务时长 `s_i`；
- 给定一支同质车队，单车容量 `Q`、车辆数上限 `V_max`；
- 求一组路线，使每个客户被准时服务一次，所有路线起止于仓库；
- **主目标**：最少化车辆数 `NV`；**次目标**：最少化总行驶距离 `TD`。

**距离公式**：`EUC_2D_X10`，即 `dist(a,b) = round(sqrt((ax-bx)^2 + (ay-by)^2) * 10) / 10`。

**评分**：对每个实例 i 与 BKS（最佳已知解）`(NV*, TD*)`：
```
gap_NV = max(0, NV - NV*)
gap_TD% = max(0, (TD - TD*) / TD* * 100)
score_i = max(0, 100 - 30 * gap_NV - 0.5 * gap_TD%)

# BKS 突破奖励
if NV  < NV*:                     score_i += 30 * (NV* - NV)
if NV <= NV* and TD < TD*:        score_i += min(30, 1.0 * (TD* - TD) / TD* * 100)

score_i = min(score_i, 160)
if not feasible or timeout:       score_i = 0
```
3 组数据集加权求和、归一化为最终分数（详见 `任务说明.md` §"评分公式"）。

## 2. 必须遵守的接口

```
./cvrptw_solver <input.txt> <output.txt> <time_budget_sec>
```
- **stdin/stdout 不参与评测**。所有数据在文件里。
- 退出码 0 表示正常；非 0 视为崩溃，该实例 `score = 0`。
- 不允许 `fork`、`exec`、起子进程；线程总数 ≤ 4。
- 不允许写除 `<output.txt>` 之外的任何路径（评测端 `--read-only`，会强制失败）。

## 3. I/O 格式

**输入**（Solomon 扩展 ASCII 文本）：
```
NAME : R101
DIMENSION : 101            # 客户 + 1 个 depot
CAPACITY : 200
MAX_VEHICLES : 25
EDGE_WEIGHT_TYPE : EUC_2D_X10
NODE_COORD_SECTION
0  35.0  35.0              # depot 必须 id=0
1  41.0  49.0
...
DEMAND_SECTION
0  0
1  10
...
TIME_WINDOW_SECTION
0  0     230               # depot 时间窗 = [0, l_0] 决定车辆作业时长
1  161   171
...
SERVICE_TIME_SECTION
0  0
1  10
...
DEPOT_SECTION
0
-1
EOF
```

**输出**（必须严格匹配）：
```
Routes: 3
Route 1: 0 5 12 0
Route 2: 0 7 21 33 0
Route 3: 0 4 18 25 0
Cost: 845.30
```
- `Routes: <NV>` 必须与下方 Route 行数一致。
- 每条 Route 必须以 `0 ` 开始、以 ` 0` 结束（depot id = 0）。
- `Cost: x.xx` 严格 2 位小数，且需与远端 verify 用 `EUC_2D_X10` 公式重算结果差距 ≤ 0.05。

## 4. 编译与运行

```bash
make                                    # 产出 cvrptw_solver 与 tools/verify
./cvrptw_solver instances/public/C101.txt out.sol 60
./tools/verify instances/public/C101.txt out.sol     # 独立校验
python3 tools/format_check.py out.sol                # 格式静态检查
```

批量本地评测：
```bash
make bench                              # 在 instances/public/ 下跑全部实例
cat out_bench.csv                       # 查看 per-instance 得分
```

## 5. 起点：Baseline

`src/solver.cpp` 提供一个**最近邻 + Push-Forward 插入** baseline（约 240 行），保证可行性。
- 逻辑：从仓库出发，每次贪心选择"满足容量与时间窗约束的最近未访问客户"，直到无法继续，开新车。
- 在 3 个示例实例上 bench 平均 ≈ 36（baseline 弱在 NV gap 大）；在真实 56 个 Solomon-100 实例上综合分仅 **10**（多数实例 NV 远超 BKS 被扣到 0；4+3=7 个 R/RC 实例直接超 MAX_VEHICLES 不可行）。
- **明显短板**：无任何全局优化；C 类紧时间窗实例上几乎全军覆没（NV gap 平均 +7.4，TD gap 平均 +138%）；R/RC 上经常超过 MAX_VEHICLES=25。

你完全可以重写 `src/solver.cpp`，或新增 `src/*.cpp` / `include/*.h`。**唯一约束**：保持二进制名 `cvrptw_solver` 与上述 CLI 接口。

## 6. 优化方向（建议路线图）

| 阶段 | 技术栈 | 预期综合分 (56 实例) |
|---|---|---|
| 0 | Baseline（已给，NN+PF） | **10** (实测) |
| 1 | + 修可行性（保证 NV ≤ MAX_VEHICLES） | 1500–3000 |
| 2 | + Solomon-I1 + 2-opt + Or-opt | 3500–5000 |
| 3 | ALNS（Random/Worst/Shaw Removal + Greedy/Regret-k Insertion） | 5000–6500 |
| 4 | + 近邻列表剪枝、PF/PB slack 增量评估、SA 接受准则、扰动重启 | **7000–8000**（与出题人参考解 alns_v1 实测 = 7929 同档） |
| 5 | + 修复 ALNS 不可行 hard variants + Set Partitioning + SISR + 多线程 | 8500–9500 |
| 6 | + 突破 BKS 的精细化（3-opt、LK-cross、学习引导算子） | 9500–10000 |

理论上限 = mean score = 100 → total_score = **10000**（持平 BKS）；包含 BKS 突破奖励上限 ≈ mean = 130 → total_score = 13000。

参考论文（建议本地缓存离线，**远端禁网**）：
- Solomon 1987（构造启发式 I1）
- Pisinger & Røpke 2007 / Røpke & Pisinger 2006（ALNS）
- Vidal et al. 2013（HGS）
- Christiaens & Vanden Berghe 2020（SISR）

## 7. 工具说明

- `tools/verify`（C++ 独立验证器）：检查可行性 + 重算 cost；返回 `feasible / NV / TD`。
- `tools/format_check.py`：格式静态检查，比 verify 更快（不重算 cost）。
- `tools/bench.sh`：批量在 `instances/public/` 上运行求解器，按规模自动分配预算，输出 CSV。

## 8. 资源限制

- 远端容器：4 vCPU / 8 GB / 20 GB 磁盘 / Ubuntu 22.04 / g++ 12.2 / `-O3 -march=x86-64-v3`
- 时间预算（单实例）：60 秒（所有 56 实例均为 100 客户）
- 总评测预算上限：20 分钟；每实例最多 60 秒，并受剩余总时限截断
- 不允许 GPU / 第三方求解库 / 联网。

## 9. 提交

打包 `src/`、`include/`、`Makefile`（以及任何你新加的目录），上传到远端评测端：
```bash
tar czf submit.tar.gz src include Makefile
# curl -H "X-Agent-Token: <你的 token>" -F "file=@submit.tar.gz" <evaluation_server>/submit
```

提交上限 60 次，最终得分取所有提交里的最大值。


Hidden evaluation enforces a 20-minute total judge wall-clock budget for the whole submission; per-instance 60-second calls are capped by the remaining global budget.
