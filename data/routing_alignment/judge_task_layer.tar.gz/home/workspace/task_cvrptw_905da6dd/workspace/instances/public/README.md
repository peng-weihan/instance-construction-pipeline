# instances/public/ — 公开实例集

> 本目录托管 56 个公开 CVRPTW 实例（Solomon 100 + Gehring-Homberger 200/400/600/800/1000）
> 供 Agent 在本地快速迭代。**远端评测使用相同实例的"节点编号置乱副本"。**

## 目录内容

仓库默认携带 3 个 **手工编写的小型示例实例**（10-30 节点，便于秒级快速调试）：

| 文件 | N | 类型 | BKS (NV, TD) |
|---|---|---|---|
| `EX_C25.txt`  | 25 | C 类（聚类、紧时间窗） | (3, 191.70) |
| `EX_R20.txt`  | 20 | R 类（分散、松时间窗） | (3, 336.70) |
| `EX_RC15.txt` | 15 | RC 类（混合）         | (4, 405.20) |

完整 56 实例需通过 `fetch_solomon.sh` 安装（远端禁网，仅本地环境可用）：
```bash
cd instances/public
# Offline mode (推荐):  使用赛事运营提供的 tarball
bash fetch_solomon.sh --offline /path/to/cvrptw-bundle-v1.0.tar.gz
```
将 56 组 `*.txt` + `*.bks` 解压到本目录。

> 由于 SINTEF / CVRPLIB 不再提供统一打包下载点（每个实例需要单独抓取且站点结构会变），
> 推荐使用赛事运营团队预先打包好的 `cvrptw-bundle-vX.Y.tar.gz`（与远端评测使用同一份数据，
> 只是未做节点编号置乱）。如何获取该 tarball，请咨询你的赛事运营对接人。

## .bks 文件格式

每个 `<name>.bks` 文件一行：`<NV> <TD>`，如 `25 828.94`。
- BKS 来自 SINTEF/CVRPLIB 公开榜单（2024 年快照）。
- 这些值仅用于 Agent 本地评估自己的得分；**远端评测使用独立保存的 BKS 表**，对每次提交重新计算。

## 数据来源声明

- Solomon 100：M.M. Solomon, "Algorithms for the vehicle routing and scheduling problem with time window constraints", Operations Research 35(2), 1987.
- Gehring-Homberger 200-1000：H. Gehring, J. Homberger, "A parallel hybrid evolutionary metaheuristic for the vehicle routing problem with time windows", 1999.
- 数据集免费用于学术评测（参考 SINTEF 官方使用条款）。
